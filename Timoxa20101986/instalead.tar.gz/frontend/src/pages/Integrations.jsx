import React, { useEffect, useState } from 'react';
import { CheckCircle, Eye, EyeOff, Search, MessageSquare, Bot, AlertTriangle, Loader2 } from 'lucide-react';
import api from '../utils/api.js';

// Shortcuts are only a convenience: the field below accepts any OpenRouter
// model id typed by hand (vendor/model), including models added after release.
const MODEL_PRESETS = [
  { id: 'openai/gpt-4o-mini', label: 'OpenAI GPT-4o mini — рекомендуется' },
  { id: 'openai/gpt-4o', label: 'OpenAI GPT-4o' },
  { id: 'anthropic/claude-3.5-sonnet', label: 'Anthropic Claude 3.5 Sonnet' },
  { id: 'anthropic/claude-sonnet-4', label: 'Anthropic Claude Sonnet 4' },
  { id: 'google/gemini-2.0-flash-001', label: 'Google Gemini 2.0 Flash' },
  { id: 'stealth/space-bunny-alpha', label: 'Stealth Space Bunny Alpha' }
];

const MODEL_ID_PATTERN = /^[a-z0-9._-]+\/[a-z0-9._:-]+$/i;

function FeatureItem({ icon: Icon, title, desc }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-lg bg-gray-50 border border-gray-100">
      <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center flex-shrink-0">
        <Icon size={16} className="text-orange-600" />
      </div>
      <div>
        <div className="text-sm font-medium text-gray-800">{title}</div>
        <div className="text-xs text-gray-500 mt-0.5">{desc}</div>
      </div>
    </div>
  );
}

export default function Integrations() {
  const [settings, setSettings] = useState({});
  const [showKey, setShowKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    api.get('/settings').then(setSettings).catch(console.error);
  }, []);

  const save = async () => {
    setSaving(true);
    setTestResult(null);
    try {
      await api.put('/settings', settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  // Проверяет именно текущие значения из полей, даже если они ещё не сохранены.
  const testConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await api.post('/settings/test-openrouter', {
        openrouter_api_key: settings.openrouter_api_key,
        openrouter_model: settings.openrouter_model
      });
      setTestResult(result);
    } catch (e) {
      setTestResult({ ok: false, error: e?.error || e?.message || 'Не удалось выполнить проверку' });
    }
    setTesting(false);
  };

  const hasKey = settings.openrouter_api_key && settings.openrouter_api_key !== '' && settings.openrouter_api_key !== '***masked***';
  const isMasked = settings.openrouter_api_key === '***masked***';

  const modelValue = settings.openrouter_model || 'openai/gpt-4o-mini';
  const modelTouched = settings.openrouter_model !== undefined && settings.openrouter_model !== '';
  const modelInvalid = modelTouched && !MODEL_ID_PATTERN.test(modelValue.trim());

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Интеграции</h1>
        <p className="text-gray-500 text-sm mt-1">Подключите AI для генерации сообщений</p>
      </div>

      <div className="card border-orange-200 bg-gradient-to-br from-orange-50/50 to-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center text-white text-xl">
              🔗
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">OpenRouter</h2>
              <p className="text-sm text-gray-500">Один API ключ — доступ к десяткам AI моделей</p>
            </div>
          </div>
          {(hasKey || isMasked) ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 border border-green-200">
              <CheckCircle size={12} /> Подключено
            </span>
          ) : (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-500">
              Не подключено
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
          <FeatureItem icon={Search} title="Lead Finder" desc="Квалификация лидов через AI анализ профилей" />
          <FeatureItem icon={MessageSquare} title="Кампании" desc="Персонализация сообщений для каждого лида" />
          <FeatureItem icon={Bot} title="Inbox Agent" desc="Автоматические ответы на входящие сообщения" />
        </div>

        <label className="block text-sm font-medium text-gray-700 mb-2" htmlFor="openrouter-model">AI-модель</label>
        <input
          id="openrouter-model"
          className={`input w-full font-mono text-sm mb-2 ${modelInvalid ? 'border-red-300' : ''}`}
          list="openrouter-model-list"
          value={modelValue}
          onChange={e => setSettings(prev => ({ ...prev, openrouter_model: e.target.value }))}
          placeholder="vendor/model — например stealth/space-bunny-alpha"
          spellCheck={false}
        />
        <datalist id="openrouter-model-list">
          {MODEL_PRESETS.map(m => (
            <option key={m.id} value={m.id}>{m.label}</option>
          ))}
        </datalist>
        <p className="text-xs text-gray-500 -mt-1 mb-4">
          Можно выбрать из списка или вписать любой ID модели OpenRouter в формате <code>vendor/model</code>.
          Если модель вернула 403, попробуй другую модель или другой ключ и нажми «Проверить».
        </p>
        {modelInvalid && (
          <p className="text-xs text-red-600 -mt-2 mb-3 flex items-center gap-1">
            <AlertTriangle size={12} /> Некорректный ID модели: ожидается vendor/model
          </p>
        )}

        <div className="flex gap-2">
          <div className="relative flex-1">
            <input
              className="input pr-10 font-mono text-sm"
              type={showKey ? 'text' : 'password'}
              value={settings.openrouter_api_key || ''}
              onChange={e => setSettings(prev => ({ ...prev, openrouter_api_key: e.target.value }))}
              placeholder="sk-or-..."
            />
            <button
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setShowKey(!showKey)}
            >
              {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          <button onClick={save} disabled={saving || modelInvalid} className="btn-primary px-6">
            {saving ? '...' : saved ? 'Сохранено!' : 'Сохранить'}
          </button>
          <button
            onClick={testConnection}
            disabled={testing || modelInvalid}
            className="btn-secondary px-5 flex items-center gap-2 whitespace-nowrap"
          >
            {testing ? <Loader2 size={14} className="animate-spin" /> : null}
            {testing ? 'Проверка...' : 'Проверить'}
          </button>
        </div>

        {testResult && (
          <div className={`mt-3 text-sm flex items-start gap-1.5 ${testResult.ok ? 'text-green-600' : 'text-red-600'}`}>
            {testResult.ok ? <CheckCircle size={14} className="mt-0.5 flex-shrink-0" /> : <AlertTriangle size={14} className="mt-0.5 flex-shrink-0" />}
            <span>
              {testResult.ok
                ? `Модель ${testResult.model} ответила: ${testResult.reply}`
                : `Проверка не прошла (${testResult.model || 'модель не задана'}): ${testResult.error}`}
            </span>
          </div>
        )}

        {saved && (
          <div className="mt-3 text-sm text-green-600 flex items-center gap-1">
            <CheckCircle size={14} /> Настройки OpenRouter сохранены
          </div>
        )}
      </div>
    </div>
  );
}
