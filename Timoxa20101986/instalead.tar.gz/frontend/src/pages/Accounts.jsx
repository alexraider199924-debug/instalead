import React, { useEffect, useState } from 'react';
import { Globe, RefreshCw, CheckCircle, AlertCircle, Shield, Check } from 'lucide-react';
import api from '../utils/api.js';

function Toggle({ value, onChange }) {
  return (
    <button onClick={() => onChange(!value)} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${value ? 'bg-green-500' : 'bg-gray-300'}`}>
      <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform shadow ${value ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
  );
}

export default function Accounts() {
  const [account, setAccount] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [warmup, setWarmup] = useState(null);
  const [warmupLoading, setWarmupLoading] = useState(false);
  const [pairCode, setPairCode] = useState(null);
  const [pairLoading, setPairLoading] = useState(false);

  const load = () => {
    api.get('/extension/account').then(d => {
      setAccount(d.username);
    }).catch(() => {}).finally(() => setLoading(false));
    api.get('/accounts/warmup').then(w => setWarmup(w)).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const refresh = async () => {
    setRefreshing(true);
    try {
      await api.post('/accounts/refresh');
      load();
    } catch (e) { console.error(e); }
    setRefreshing(false);
  };

  const toggleWarmup = async (enabled) => {
    setWarmupLoading(true);
    try {
      const w = await api.post('/accounts/warmup/toggle', { enabled });
      setWarmup(w);
    } catch (e) { console.error(e); }
    setWarmupLoading(false);
  };

  const generatePairCode = async () => {
    setPairLoading(true);
    try {
      const result = await api.post('/extension/pair/code');
      setPairCode(result);
    } catch (e) {
      console.error(e);
    }
    setPairLoading(false);
  };

  const disconnect = async () => {
    if (!window.confirm('Отключить аккаунт? Данные аккаунта сохранятся и будут доступны при повторном подключении.')) return;
    try {
      await api.post('/extension/account/disconnect');
    } catch (e) { console.error(e); }
    document.cookie = 'instalead_ws=; path=/; max-age=0';
    document.cookie = 'instalead_ws=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
    window.location.reload();
  };

  const warmupPercent = warmup?.day_number ? Math.min(100, (warmup.day_number / 21) * 100) : 0;

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Accounts</h1>
        <p className="text-gray-500 text-sm mt-1">Manage Instagram accounts and warm-up settings.</p>
      </div>

      <div className="card">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-4">Connected Account</h2>
        <div className="mb-5 rounded-xl border border-blue-200 bg-blue-50 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-sm font-semibold text-blue-900">Securely pair the Chrome extension</div>
              <div className="text-xs text-blue-700 mt-1">Generate a one-time code, then enter it in the extension while Instagram is open.</div>
            </div>
            <button onClick={generatePairCode} disabled={pairLoading} className="btn-secondary whitespace-nowrap text-sm">{pairLoading ? 'Generating…' : 'Get code'}</button>
          </div>
          {pairCode && (
            <div className="mt-3 flex items-center justify-between rounded-lg bg-white border border-blue-200 px-3 py-2">
              <div>
                <div className="text-[10px] uppercase tracking-wider text-blue-500">Expires in 10 minutes</div>
                <div className="font-mono text-2xl font-bold tracking-[0.25em] text-blue-900">{pairCode.code}</div>
              </div>
              <button onClick={() => navigator.clipboard?.writeText(pairCode.code)} className="text-xs text-blue-600 hover:underline">Copy</button>
            </div>
          )}
        </div>

        {loading ? (
          <div className="text-gray-400 text-sm">Loading...</div>
        ) : account ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-pink-500 flex items-center justify-center text-white font-bold text-lg">
                {account[0].toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-semibold text-gray-900">@{account}</span>
                  {warmup?.warmed_up && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200">
                      <Check size={12} /> Warmed up
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 text-sm text-green-600 mt-0.5">
                  <CheckCircle size={14} />
                  <span>Active</span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={refresh} disabled={refreshing} className="btn-secondary flex items-center gap-2 text-sm">
                <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
                Refresh
              </button>
              <button onClick={disconnect} className="btn-danger text-sm px-4 py-2 rounded-lg font-medium transition-colors bg-red-50 text-red-600 hover:bg-red-100">
                Disconnect
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertCircle className="mx-auto text-gray-300 mb-3" size={40} />
            <p className="text-gray-600 font-medium">No account connected</p>
            <p className="text-sm text-gray-400 mt-2 max-w-sm mx-auto">
              Install the Instalead Chrome extension and log into Instagram in your browser. The extension will detect your account automatically.
            </p>
          </div>
        )}
      </div>

      {/* Warm-Up Section */}
      <div className="card mt-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
              <Shield size={20} className="text-orange-600" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-gray-900">Account Warm-Up</h2>
              <p className="text-xs text-gray-500">Gradually increase sending to protect your account.</p>
            </div>
          </div>
          <Toggle
            value={warmup?.enabled || false}
            onChange={(v) => toggleWarmup(v)}
          />
        </div>

        {warmup?.enabled ? (
          <div className="space-y-4">
            <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-orange-700">Day {warmup.day_number} of 21</span>
                <span className="text-xs text-orange-500 font-medium">{warmup.days_remaining} days remaining</span>
              </div>
              <div className="w-full bg-orange-200 rounded-full h-3">
                <div className="bg-orange-500 h-3 rounded-full transition-all duration-500" style={{ width: `${warmupPercent}%` }} />
              </div>
              <div className="flex justify-between mt-2">
                <span className="text-[10px] text-orange-400">Started</span>
                <span className="text-[10px] text-orange-400">21 days</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Max Messages / Day</div>
                <div className="text-2xl font-bold text-gray-900">{warmup.max_messages}</div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Max Follows / Day</div>
                <div className="text-2xl font-bold text-gray-900">{warmup.max_follows}</div>
              </div>
            </div>

            <div className="text-xs text-gray-500 space-y-1">
              <p>During warm-up, campaign daily limits are capped at {warmup.max_messages} DMs/day and {warmup.max_follows} follows/day.</p>
              <p>After 21 days, limits are removed and your account is marked as warmed up.</p>
              <p>You can disable warm-up at any time to switch to default sending mode.</p>
            </div>
          </div>
        ) : warmup?.warmed_up ? (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <Check size={20} className="text-green-600" />
              </div>
              <div>
                <div className="text-sm font-semibold text-green-700">Account Warmed Up</div>
                <p className="text-xs text-green-600 mt-0.5">21-day warm-up completed. No daily limits enforced. You can re-enable warm-up anytime.</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
            <div className="text-sm text-gray-600">Warm-up is off. Enable it to gradually ramp up sending volume over 21 days:</div>
            <ul className="mt-2 space-y-1 text-xs text-gray-500">
              <li>Max 15 messages per day during warm-up</li>
              <li>Max 15 follows per day during warm-up</li>
              <li>21-day duration with visible progress</li>
              <li>After completion, limits are lifted and account is marked as warmed up</li>
            </ul>
          </div>
        )}
      </div>

      <div className="card mt-6">
        <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">How It Works</h2>
        <ul className="space-y-2 text-sm text-gray-600">
          <li>Instalead uses the Instagram account logged into your Chrome browser.</li>
          <li>To switch accounts, log into a different Instagram account in Chrome, then refresh.</li>
          <li>You can close the Instagram tab — it does not need to stay open.</li>
          <li>To run multiple accounts, use separate Chrome profiles.</li>
        </ul>
      </div>
    </div>
  );
}
