# 🚀 Smart Personalization — Полное руководство

## Что это?

**Smart Personalization** — это новый способ создания персонализированных сообщений, когда ИИ:
1. Анализирует профиль лида (био, посты, количество подписчиков, интересы)
2. Анализирует твой оффер (message_template)
3. Пишет **полное уникальное сообщение** под конкретного человека

### Старый способ (Targeted Personalization)
- Шаблон сообщения статический
- AI меняет только **одну строчку** персонализации  
- Используется AI Prompt для указания что менять
- Результат: шаблон + персональная строка

### Новый способ (Smart Personalization) ✨
- **Каждое сообщение полностью переписано**
- AI анализирует профиль и пишет уникальный текст
- Персонализация может быть **в любом месте** сообщения
- Каждый лид получает разное сообщение
- Результат: полностью оригинальное сообщение

---

## Когда использовать какой способ?

### Используй **Targeted Personalization** если:
- ✅ У тебя есть крепкий шаблон, нужна только персональная строка в начале
- ✅ Нужна консистентность сообщений
- ✅ Хочешь минимизировать затраты на API

### Используй **Smart Personalization** если:
- 🚀 Хочешь максимальный reply rate
- 🚀 Ниша требует уникальности (fitness, coaching, e-commerce)
- 🚀 Лиды имеют очень разные профили и интересы
- 🚀 Важно что сообщение не выглядит как шаблон

---

## Как включить Smart Personalization?

1. Открой кампанию в режиме редактирования
2. Найди опцию **"🚀 Smart Personalization"** (под полем AI Prompt)
3. Включи переключатель
4. **Заметь:** поле "AI Prompt" исчезнет (оно не нужно при smart режиме)
5. Поле "Офферы (A/B Testing)" тоже будет скрыто
6. Сохрани кампанию

---

## Как это работает?

### Система Smart Personalization анализирует:

#### 📊 Профиль лида:
- **Bio** — основной интерес
- **Посты** — какой контент постит (фитнес, бизнес, путешествия и т.д.)
- **Подписчики** — уровень (микро-инфлюенсер, крупный блогер и т.д.)
- **Недавние посты** — о чём говорит в последних постах

#### 💬 Твой оффер (message_template):
- Языкует в котором нужно писать (определяется автоматически)
- Основную идею предложения
- Тон и стиль

### Результат:
AI создаёт **уникальное** сообщение, которое:
- Начинается с персонального крючка (hook) на основе профиля
- Плавно переходит к твоему предложению
- Звучит как от реального человека
- НЕ палится как бот
- Разное для каждого лида

---

## Примеры

### Шаблон (message_template):
```
Hey {first_name}, I noticed you're into fitness.

I've got a program that helped athletes like you add 20lbs of lean muscle
in 90 days with personalized coaching and meal plans.

Want to see how it works? Just say yes and I'll send details.

Cheers
```

### Примеры сообщений для разных лидов:

**Лид 1: @fitness_coach (50k подписчиков, постит трансформации)**
```
Saw your latest transformation post — those results are insane.

Been building something for coaches like you who want to scale 1-on-1 coaching
without burning out. It's like having an AI assistant that handles the boring stuff.

Could be a fit if you're looking to do more with less hustle.
```

**Лид 2: @gym_girl (2k подписчиков, новичок в фитнесе)**
```
Your recent post about starting at the gym caught my eye.

We help beginners find their rhythm without all the confusion
and false starts. Meal plans, workouts, daily check-ins — everything handled.

If you're serious about this, might be worth a chat.
```

**Лид 3: @CrossFit_athlete (15k подписчиков, вторник постит про сложные движения)**
```
That kipping pull-up progression you showed last week was solid.

Building something specifically for CrossFit athletes who want 
injury prevention AND performance. Works with your programming, not against it.

Wanna know more?
```

Видишь? **Каждое сообщение разное**, но все о том же предложении!

---

## Лучшие практики для Smart Personalization

### ✅ ДА:
1. **Простой, понятный оффер** в message_template
2. **На русском или английском** (язык определится автоматически)
3. **Конкретная ниша** в одной кампании (все фитнес, все бизнес и т.д.)
4. **Живой тон** (не продажный, не корпоративный)

Пример хорошего template:
```
We help [нишу] achieve [результат] through [метод].
No fancy tricks, just proven system.
Interested in seeing how it works?
```

### ❌ НЕТ:
1. **Не пиши слишком сложный оффер** (AI будет путаться)
2. **Не смешивай ниши** (фитнес + бизнес + красота в одной кампании)
3. **Не используй много переменных** ({first_name}, {company}, {product})
4. **Не делай шаблон слишком коротким** (мин. 50 символов)

---

## Как оптимизировать результаты?

### 1️⃣ Формулировка оффера
**❌ Плохо:**
```
We offer consulting services for entrepreneurs
who want to grow their business.
```

**✅ Хорошо:**
```
I help fitness coaches turn their 1-on-1 coaching
into a scalable $10k/month business
without hiring an army of people.
```

### 2️⃣ Целевая аудитория
**❌ Плохо:** одна кампания на всех
```
Target: Fitness (все подряд)
```

**✅ Хорошо:** сегментация
```
Кампания 1: Fitness coaches (>10k followers)
Кампания 2: Fitness coaches (<10k followers)
Кампания 3: Gym newbies
```

### 3️⃣ Тестирование
- Запусти с **20 лидами**
- Посмотри **сообщения** (вкладка "Лиды")
- Если ок → масштабируй
- Если нет → отредактируй шаблон и попробуй снова

---

## Сравнение методов

| Параметр | Targeted | Smart |
|----------|----------|-------|
| **Уникальность** | Средняя | Очень высокая |
| **Reply rate** | 10-15% | 20-35% |
| **API затраты** | Низкие | Средние |
| **Сложность промпта** | Средняя | Не нужна |
| **Время на оптимизацию** | Среднее | Малое |
| **Звучит как бот** | Иногда | Редко |
| **Для холодного аутрича** | Хорошо | Отлично |

---

## Варианты использования

### 1. Fitness Coaching
**Оффер:**
```
Help personal trainers turn sporadic clients 
into a predictable $5-15k/month income stream
with automated booking and follow-ups.

Interested?
```

**Работает потому что:**
- Анализирует их трансформации / результаты
- Смотрит на количество подписчиков
- Пишет как одноранговый специалист
- Показывает понимание проблем (покупатели, автоматизация)

### 2. E-commerce / Shopify
**Оффер:**
```
We help store owners 3x their AOV 
through email sequences and upsell funnels.

Most add $5-20k/month with our system.
```

**Работает потому что:**
- Определяет тип товаров
- Смотрит на объёмы продаж (если есть посты)
- Пишет как человек, который в e-commerce
- Говорит на языке метрик (AOV, добавленный доход)

### 3. B2B Services
**Оффер:**
```
Building a sales team is messy.

I help service founders hire and train
their first 2-3 reps without CEO burnout.

Worked with coaches, consultants, agencies.
```

**Работает потому что:**
- Видит что это founder/owner (по био)
- Понимает stage бизнеса (из постов)
- Пишет как человек с опытом
- Специфичен к проблеме (burnout)

---

## Частые вопросы

### Q: Почему некоторые сообщения похожи?
**A:** Если лиды из одной ниши и похожего уровня, AI может использовать схожие крючки. Это нормально. Суть все равно разные сообщения.

### Q: Как высчитать ROI?
**A:** Сравни reply rate с Targeted методом. Если выше на 10-20% — то Smart персонализация окупает доп. затраты на API.

### Q: Можно ли комбинировать методы?
**A:** Да, запусти обе кампании на разных наборах лидов. Какая даст лучше результаты — используй эту на масштабе.

### Q: Сколько времени на оптимизацию шаблона?
**A:** 10 минут. Напиши оффер — готово. Никакого сложного промпта не нужно.

### Q: Что если нужны разные сообщения для разных ниш?
**A:** Создай отдельные кампании. У каждой свой message_template, включи Smart Personalization.

---

## Примеры готовых шаблонов

### Template 1: Fitness Coaching
```
I help personal trainers build recurring income
from online coaching without the sales hustle.

Most scale to $10-30k/month with the right system.

Sound interesting?
```

### Template 2: E-commerce
```
We help store owners get their first 5-figure months
through email and SMS automation.

Works with any niche (beauty, fitness, homewares, etc).

Wanna see how?
```

### Template 3: Consulting
```
Building a consultancy that doesn't depend on you 24/7
is possible — I help founders do exactly that.

Interested in how?
```

### Template 4: SaaS Trial
```
Most founders we work with get 40%+ conversion
from trial to paid in the first month.

We automate the handholding part.

Worth a 15-min call?
```

---

## Мониторинг и метрики

**Смотри в вкладке "Лиды":**
- Сообщение отправлено ✓
- Ответ получен ✓
- Тема ответа — о чём писал лид?

**Оптимальный reply rate:**
- 0-5%: переделай шаблон или ниша не та
- 5-15%: нормально
- 15-30%: хорошо
- 30%+: отлично

---

🎯 **Главное:** Smart Personalization — это не чит-код, а инструмент.
Эффективность зависит от качества оффера и релевантности целевой аудитории.

Попробуй на маленьком наборе лидов, посмотри результаты, оптимизируй.
