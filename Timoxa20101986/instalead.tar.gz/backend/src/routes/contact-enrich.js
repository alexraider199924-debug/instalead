import { Router } from 'express';
import { getMoscowISO } from '../services/schedulerService.js';
import { getDailyBudget, getBudgetUsedToday, spendBudget } from './lead-finder.js';
import { enrichProfiles, ENRICH_VERSION, ENRICH_LIMITS } from '../services/contactEnrichService.js';
import { readAgentContextMap } from '../services/offerContext.js';
import { createEnrichJob, jobWithProgress } from '../services/contactEnrichJob.js';
import { notify } from '../services/notifier.js';

const router = Router();

// ---------------------------------------------------------------------------
// Pacing.
//
// Enrichment is the lowest-priority Instagram consumer in the system: it never
// runs while a campaign is sending or while Lead Finder / AI Search have work,
// and it time-boxes itself into resumable blocks. That makes "run it in the
// background overnight" the default rather than something the user has to
// babysit — the job survives the extension disconnecting and picks up where it
// stopped.
//
// Delays are decided here and shipped with the task, so pacing cannot be
// shortened by editing the extension.
// ---------------------------------------------------------------------------
// Declared in the service next to the batch size it derives from, so pacing and
// batch size cannot drift apart.
export { ENRICH_LIMITS };

const randBetween = (min, max) => Math.round(min + Math.random() * (max - min));

// last_progress_at is written in UTC and ONLY ever compared against SQLite's
// datetime('now'), which is UTC. The rest of the app stamps rows with
// getMoscowISO(), and mixing the two here would silently skew every time-box
// comparison by three hours: a job started at 12:00 Moscow would look 20
// minutes old only six hours later, so the "run for an hour, then pause"
// behaviour the feature is built on would never fire.
//
// Displayed timestamps keep using getMoscowISO() like everything else; this
// one column is the exception, and the format is ISO-8601 precisely because
// julianday() parses it unambiguously.
const nowUtc = () => new Date().toISOString();

function budgetState(db) {
  const limit = getDailyBudget(db);
  const used = getBudgetUsedToday(db);
  return { limit, used, remaining: Math.max(0, limit - used) };
}

const normalizeUsername = value =>
  String(value || '').trim().replace(/^@/, '').toLowerCase();

// One place decides whether a job is finished, because three callers used to
// disagree about it and a job that only closed itself on the extension's next
// poll sat at 0% forever once the browser was closed.
function isJobFinished(db, jobId) {
  const row = db.prepare(`
    SELECT COUNT(*) AS total,
           SUM(CASE WHEN scraped = 0 AND summarized = 0 THEN 1 ELSE 0 END) AS pending
    FROM contact_enrich_results WHERE job_id = ?
  `).get(jobId);
  // A job with no result rows at all is not "finished", it never started.
  return (row?.total || 0) > 0 && (row?.pending || 0) === 0;
}

// Called from the read endpoints so a job closes itself the moment its last row
// is banked, without waiting for an extension that may never come back.
// Exported for the test that pins the behaviour — this is the difference between
// a job that closes itself and one that reads 0% forever.
export function autoFinish(db, jobId) {
  const job = db.prepare('SELECT status FROM contact_enrich_jobs WHERE id = ?').get(jobId);
  if (!job || !['pending', 'running'].includes(job.status)) return null;
  if (!isJobFinished(db, jobId)) return null;
  const done = finishJob(db, jobId);
  console.log(`[ContactEnrich] Job #${jobId} auto-finished: every contact is accounted for`);
  return done;
}

// Why a job that is not moving is not moving, in words the UI can show. An
// open-ended "0%" is the one screen a user cannot act on.
function stalledReason(db, job) {
  if (!job || !['pending', 'running'].includes(job.status)) return null;

  const row = db.prepare(`
    SELECT (julianday('now') - julianday(COALESCE(last_progress_at, created_at))) * 1440 AS minutes
    FROM contact_enrich_jobs WHERE id = ?
  `).get(job.id);
  const idle = row?.minutes ?? 0;

  // Two minutes is longer than a normal batch (10 profiles, 20-45 s cooldown)
  // but far shorter than the "abandoned" threshold — this is the window where
  // the honest answer is "the extension has not picked it up yet".
  if (idle > 2) {
    return `Нет движения ${Math.round(idle)} мин — расширение не подключено или не опрашивает задачу. Откройте Chrome с расширением Instalead.`;
  }
  return null;
}

function setStatus(db, id, status, extra = {}) {
  const finished = ['completed', 'failed', 'cancelled'].includes(status);
  db.prepare(`
    UPDATE contact_enrich_jobs
    SET status = ?, error_message = COALESCE(?, error_message), updated_at = ?,
        finished_at = CASE WHEN ? = 1 THEN ? ELSE finished_at END
    WHERE id = ?
  `).run(status, extra.error_message ?? null, getMoscowISO(), finished ? 1 : 0, getMoscowISO(), id);
  console.log(`[ContactEnrich] Job #${id} → ${status}${extra.error_message ? `: ${extra.error_message}` : ''}`);
  return db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(id);
}

// progress + the "why is it not moving" sentence, so no caller has to
// remember to add the second one.
function decorate(db, job) {
  const progress = jobWithProgress(db, job);
  if (!progress) return null;
  const stalled = stalledReason(db, job);
  return {
    ...progress,
    stalled_reason: stalled,
    // Everything is banked but the status still says running — treat it as done
    // in the UI rather than showing a bar that can only go one way.
    all_rows_done: ['pending', 'running'].includes(job.status) && progress.pending === 0 && progress.total > 0
  };
}

// ---------------------------------------------------------------------------
// Web UI endpoints
// ---------------------------------------------------------------------------

router.get('/limits', (req, res) => {
  res.json({ limits: ENRICH_LIMITS, budget: budgetState(req.db) });
});

// Only one enrichment job at a time. The other job systems each enforce the
// same for themselves; this is the remaining direction of the conflict, since
// enrichment is the one that must yield.
router.get('/jobs', (req, res) => {
  const db = req.db;
  // Close finished jobs on read: the user opening the dialog is itself proof
  // that no extension heartbeat is going to finish it for us.
  for (const row of db.prepare(
    `SELECT id FROM contact_enrich_jobs WHERE status IN ('pending','running')`
  ).all()) {
    autoFinish(db, row.id);
  }

  const jobs = db.prepare(
    'SELECT * FROM contact_enrich_jobs ORDER BY id DESC LIMIT 20'
  ).all().map(j => decorate(db, j));
  res.json({
    jobs,
    active: jobs.find(j => ['pending', 'running'].includes(j.status)) || null
  });
});

router.get('/jobs/:id', (req, res) => {
  const db = req.db;
  autoFinish(db, req.params.id);

  const job = decorate(db, db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(req.params.id));
  if (!job) return res.status(404).json({ error: 'Задача не найдена' });
  const results = db.prepare(
    'SELECT username, full_name, summary, hooks, scraped, summarized, error FROM contact_enrich_results WHERE job_id = ? ORDER BY summarized ASC, id ASC LIMIT 200'
  ).all(job.id);
  res.json({ job, results });
});

// The UI's per-row error is the first thing anyone reads when a job looks
// stuck, so it has to be actionable: a private profile says so plainly, while an
// AI or Instagram failure carries the upstream text that names the cause.
function rowErrorText(row) {
  if (row.error) return row.error;
  if (row.scraped === 1 && row.summarized === 1) return 'Конспект не создан';
  if (row.scraped === 1) return 'Профиль прочитан, конспект ещё не создан';
  return null;
}

router.post('/jobs', (req, res) => {
  const db = req.db;
  const ids = Array.isArray(req.body?.contact_ids) ? req.body.contact_ids : [];
  const rawUsernames = Array.isArray(req.body?.usernames) ? req.body.usernames : [];

  // Normalization (@-strip, lowercase, dedupe) happens inside createEnrichJob
  // so the batch endpoint and the single-contact shortcut cannot disagree
  // about what counts as the same person.
  const usernames = ids.length
    ? db.prepare(`SELECT username FROM contacts WHERE id IN (${ids.map(() => '?').join(',')})`).all(...ids).map(r => r.username)
    : rawUsernames;

  const unique = [...new Set(usernames.filter(Boolean))];
  if (!unique.length) return res.status(400).json({ error: 'Не выбрано ни одного контакта' });
  if (unique.length > ENRICH_LIMITS.MAX_CONTACTS_PER_JOB) {
    return res.status(400).json({ error: `Максимум ${ENRICH_LIMITS.MAX_CONTACTS_PER_JOB} контактов за раз` });
  }

  const active = db.prepare(
    `SELECT id FROM contact_enrich_jobs WHERE status IN ('pending','running')`
  ).get();
  if (active) {
    return res.status(409).json({ error: `Обогащение #${active.id} ещё идёт. Поставьте его на паузу или дождитесь конца.`, job_id: active.id });
  }

  const runMinutes = Math.min(
    ENRICH_LIMITS.MAX_RUN_MINUTES,
    Math.max(0, Number(req.body?.run_minutes) || ENRICH_LIMITS.DEFAULT_RUN_MINUTES)
  );

  // createEnrichJob returns the stored row, not the id — feeding it back into
  // a `WHERE id = ?` lookup silently matched nothing and answered {"job":null}.
  const job = jobWithProgress(db, createEnrichJob(db, { usernames: unique, runMinutes }));
  if (!job) return res.status(500).json({ error: 'Не удалось создать задачу' });
  res.status(201).json({ job });
});

router.post('/jobs/:id/pause', (req, res) => {
  res.json({ job: jobWithProgress(req.db, setStatus(req.db, req.params.id, 'paused')) });
});

router.post('/jobs/:id/resume', (req, res) => {
  const db = req.db;
  const job = db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Задача не найдена' });
  if (job.status === 'completed') return res.status(400).json({ error: 'Задача уже завершена' });

  // Resuming a paused job restarts its block clock. Without this the job would
  // immediately re-pause on the very next /task poll, because the time-box is
  // measured from the last progress rather than from the resume.
  setStatus(db, job.id, 'pending', { error_message: null });
  db.prepare('UPDATE contact_enrich_jobs SET last_progress_at = ?, error_message = NULL WHERE id = ?')
    .run(nowUtc(), job.id);
  res.json({ job: jobWithProgress(db, db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(job.id)) });
});

router.post('/jobs/:id/cancel', (req, res) => {
  const db = req.db;
  setStatus(db, req.params.id, 'cancelled');
  // Contacts left mid-flight would otherwise sit in "working" forever and be
  // invisible to the "not enriched" filter.
  db.prepare(`
    UPDATE leads SET enrich_status = 'none'
    WHERE username IN (
      SELECT username FROM contact_enrich_results WHERE job_id = ? AND summarized = 0 AND scraped = 0
    )
  `).run(req.params.id);
  res.json({ job: jobWithProgress(db, db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(req.params.id)) });
});

// Reviewing a note is the whole point of storing it. Edited text is written
// back to leads so the next send uses what a human decided, and the result row
// is kept in sync so a re-opened job shows the same thing.
router.post('/results/:id', (req, res) => {
  const db = req.db;
  const row = db.prepare('SELECT * FROM contact_enrich_results WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Результат не найден' });

  const summary = req.body?.summary !== undefined ? String(req.body.summary) : row.summary;
  const hooks = req.body?.hooks !== undefined ? req.body.hooks : row.hooks;

  const hooksJson = hooks === null || hooks === undefined ? row.hooks : JSON.stringify(hooks);
  const meta = JSON.stringify({
    version: ENRICH_VERSION,
    edited: true,
    hooks: safeParse(hooksJson, []),
    created_at: new Date().toISOString()
  });

  db.transaction(() => {
    db.prepare('UPDATE contact_enrich_results SET summary = ?, hooks = ?, meta = ? WHERE id = ?')
      .run(summary, hooksJson, meta, row.id);
    db.prepare(`
      UPDATE leads SET profile_summary = ?, profile_summary_meta = ?, profile_enriched_at = ?, enrich_status = 'done'
      WHERE username = ?
    `).run(summary, meta, getMoscowISO(), row.username);
  })();

  res.json({ success: true });
});

function safeParse(value, fallback) {
  try {
    const parsed = JSON.parse(value);
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

// ---------------------------------------------------------------------------
// Extension-facing endpoints
// ---------------------------------------------------------------------------

function reclaimStaleJobs(db) {
  // The extension going away is not a failure — the job simply stops and picks
  // up again when it comes back. Only genuinely abandoned runs are reclaimed,
  // so this must not race the block expiry in blockExpired(): a normal
  // one-hour block finishing is the user's own stop, not a disconnect.
  //
  // julianday(), not a string comparison: last_progress_at is stored ISO-8601
  // ("2026-10-04T19:44:19.123Z") while datetime('now') is space-separated
  // ("2026-10-04 15:44:19"). Lexically those never compare correctly — at an
  // equal date prefix 'T' outranks ' ', so every stored timestamp looked to be
  // in the future and an abandoned job was never reclaimed at all.
  db.prepare(`
    UPDATE contact_enrich_jobs
    SET status = 'paused', error_message = 'Обогачение давно не продвигалось — нажмите «Продолжить», если оно ещё нужно'
    WHERE status = 'running'
      AND last_progress_at IS NOT NULL
      AND (julianday('now') - julianday(last_progress_at)) * 1440 >= ?
  `).run(ENRICH_LIMITS.DISCONNECT_MINUTES);
}

function blockExpired(db, job) {
  if (!job.run_minutes || !job.last_progress_at) return false;
  const row = db.prepare(
    `SELECT (julianday('now') - julianday(?)) * 1440 AS minutes`
  ).get(job.last_progress_at);
  return (row?.minutes ?? -1) >= job.run_minutes;
}

export async function getEnrichTask(db) {
  reclaimStaleJobs(db);

  // Yield to everything that matters more. Campaign sending is invisible to the
  // server (the extension holds it), but these two are ours to check.
  const busy = db.prepare(
    `SELECT
       (SELECT COUNT(*) FROM scrape_jobs WHERE status IN ('pending','running')) AS scrape,
       (SELECT COUNT(*) FROM lead_search_jobs WHERE status IN ('pending','running')) AS search`
  ).get();
  if (busy.scrape || busy.search) return { task: null };

  const job = db.prepare(
    `SELECT * FROM contact_enrich_jobs WHERE status IN ('pending','running') ORDER BY id ASC LIMIT 1`
  ).get();
  if (!job) return { task: null };

  const budget = budgetState(db);
  if (budget.remaining <= 0) {
    console.log(`[ContactEnrich] Job #${job.id} idle: daily budget spent (${budget.used}/${budget.limit})`);
    return {
      task: null,
      message: `Дневной бюджет запросов исчерпан (${budget.used}/${budget.limit}). Обогащение продолжится завтра.`,
    };
  }

  if (job.status === 'pending') {
    // last_progress_at is left alone when it already has a value: on resume it
    // was deliberately reset by POST /jobs/:id/resume, and overwriting it here
    // would make a paused job's block clock restart on every poll.
    db.prepare(`
      UPDATE contact_enrich_jobs
      SET status = 'running', updated_at = ?,
          last_progress_at = COALESCE(last_progress_at, ?)
      WHERE id = ?
    `).run(getMoscowISO(), nowUtc(), job.id);
  }

  const fresh = db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(job.id);
  // Checked after the pending→running promotion so a freshly created job is
  // never judged by an inherited clock, but before any work is handed out.
  if (blockExpired(db, fresh)) {
    setStatus(db, fresh.id, 'paused', { error_message: `Блок на ${fresh.run_minutes} мин завершён. Нажмите «Продолжить» для следующего блока.` });
    return { task: null, message: `Обогащение #${fresh.id}: блок на ${fresh.run_minutes} мин завершён, ждёт продолжения.` };
  }

  // Phase 1: read profiles from Instagram.
  const batchSize = Math.min(ENRICH_LIMITS.BATCH_SIZE, budget.remaining);
  const targets = db.prepare(`
    SELECT username FROM contact_enrich_results
    WHERE job_id = ? AND scraped = 0 AND summarized = 0
    ORDER BY id ASC LIMIT ?
  `).all(job.id, batchSize).map(r => r.username);

  if (targets.length === 0) {
    return finishJob(db, job.id);
  }

  const scrapedSoFar = db.prepare(
    'SELECT COUNT(*) AS cnt FROM contact_enrich_results WHERE job_id = ? AND scraped = 1'
  ).get(job.id).cnt;
  const resting = scrapedSoFar > 0 && scrapedSoFar % ENRICH_LIMITS.BATCH_SIZE === 0;

  console.log(
    `[ContactEnrich] Job #${job.id} → extension: ${targets.length} profile(s)` +
    (resting ? ', rest between batches' : '') +
    `, delay ${resting ? 'cooldown' : 'normal'}`
  );

  return {
    task: {
      type: 'enrich_contacts',
      job_id: job.id,
      usernames: targets,
      delay_ms: resting
        ? randBetween(ENRICH_LIMITS.COOLDOWN_MIN_MS, ENRICH_LIMITS.COOLDOWN_MAX_MS)
        : randBetween(ENRICH_LIMITS.DELAY_MIN_MS, ENRICH_LIMITS.DELAY_MAX_MS),
      resting,
      progress: jobWithProgress(db, fresh),
    },
    budget
  };
}

// Phase 2: run the AI pass. Called inline from the scraped report while the
// extension is resting, so by the time the next task is due the notes are
// already stored. A failure here is banked and retried — getEnrichTask will
// hand the same rows back to the AI pass on the next poll.
async function runSummaryPass(db, jobId, maxBatches = 2) {
  const agentContext = readAgentContextMap(db);
  let written = 0;

  for (let batch = 0; batch < maxBatches; batch++) {
    const rows = db.prepare(`
      SELECT username, full_name, bio, follower_count, post_count, external_url, is_private, posts_json
      FROM contact_enrich_results
      WHERE job_id = ? AND scraped = 1 AND summarized = 0
      ORDER BY id ASC LIMIT ?
    `).all(jobId, ENRICH_LIMITS.BATCH_SIZE);

    if (!rows.length) break;

    const prepared = rows.map(r => ({
      username: r.username,
      full_name: r.full_name,
      bio: r.bio,
      follower_count: r.follower_count,
      post_count: r.post_count,
      external_url: r.external_url,
      is_private: !!r.is_private,
      posts: safeParse(r.posts_json, [])
    }));

    let notes;
    try {
      notes = await enrichProfiles(db, prepared, {
        agentContext,
        maxPosts: ENRICH_LIMITS.MAX_POSTS_PER_PROFILE
      });
    } catch (e) {
      // The single most confusing failure this feature can have: the profiles
      // were read fine, so the UI shows "прочитано" while nothing else happens,
      // forever, because the rows stay summarized=0 and every retry fails the
      // same way. A missing or wrong API key is the usual cause, so the message
      // is surfaced on the job itself rather than only in the journal.
      const human = String(e?.message || e).slice(0, 300);
      console.error(`[ContactEnrich] Job #${jobId} summary batch failed:`, e);
      db.prepare(
        `UPDATE contact_enrich_jobs SET error_message = ?, updated_at = ? WHERE id = ?`
      ).run(`ИИ не отвечает: ${human}`, getMoscowISO(), jobId);
      db.prepare(
        `UPDATE contact_enrich_results SET error = ? WHERE job_id = ? AND scraped = 1 AND summarized = 0`
      ).run(`ИИ не отвечает: ${human}`, jobId);
      break;
    }

    if (notes.size === 0) {
      console.warn(
        `[ContactEnrich] Job #${jobId}: модель вернула 0 заметок на ${prepared.length} профилей — ` +
        'проверьте модель и лимит токенов в Настройках'
      );
    }

    const write = db.prepare(`
      UPDATE contact_enrich_results SET summary = ?, hooks = ?, meta = ?, summarized = 1 WHERE job_id = ? AND username = ?
    `);
    const writeLead = db.prepare(`
      UPDATE leads SET profile_summary = ?, profile_summary_meta = ?, profile_enriched_at = ?,
        enrich_status = 'done', enrich_error = NULL
      WHERE username = ?
    `);

    db.transaction(() => {
      for (const row of prepared) {
        const note = notes.get(row.username);
        const hooksJson = note ? JSON.stringify(note.hooks) : null;
        const metaJson = note ? JSON.stringify(note.meta) : null;

        write.run(note?.summary || null, hooksJson, metaJson, jobId, row.username);
        if (note?.summary) writeLead.run(note.summary, metaJson, getMoscowISO(), row.username);
        if (note?.summary) written++;
      }
    })();

    const missed = prepared.filter(r => !notes.get(r.username)?.summary);
    if (missed.length) {
      console.warn(
        `[ContactEnrich] Job #${jobId}: ${missed.length} профиль(ей) без заметки: ${missed.map(r => r.username).join(', ')}`
      );
    }
    console.log(`[ContactEnrich] Job #${jobId}: конспектов записано ${written}/${prepared.length}`);

    // Every row in the batch is marked summarized even when the model returned
    // nothing for it — otherwise a permanently-skipped row would be re-sent to
    // the model on every poll, forever, at full price.
    if (notes.size === 0) {
      db.prepare(`
        UPDATE contact_enrich_results SET summarized = 1, error = 'Модель не вернула заметку'
        WHERE job_id = ? AND scraped = 1 AND summarized = 0
      `).run(jobId);
      break;
    }
  }

  const counts = db.prepare(`
    SELECT SUM(CASE WHEN scraped = 1 THEN 1 ELSE 0 END) AS scraped,
           SUM(CASE WHEN summarized = 1 THEN 1 ELSE 0 END) AS summarized,
           SUM(CASE WHEN error IS NOT NULL AND error != '' THEN 1 ELSE 0 END) AS failed
    FROM contact_enrich_results WHERE job_id = ?
  `).get(jobId);

  db.prepare(`
    UPDATE contact_enrich_jobs SET scraped_count = ?, summarized_count = ?, failed_count = ?,
      phase = ?, updated_at = ?, last_progress_at = ?
    WHERE id = ?
  `).run(
    counts.scraped || 0,
    counts.summarized || 0,
    counts.failed || 0,
    (counts.summarized || 0) + (counts.failed || 0) >= (jobTotal(db, jobId) || 0) ? 'done' : 'summarize',
    getMoscowISO(),
    nowUtc(),
    jobId
  );

  return written;
}

function jobTotal(db, jobId) {
  // Falls back to the real row count: a job stored with total_count=0 (older
  // rows, or a job whose contacts were all removed) compared `done >= 0` and
  // reported "done" on the very first pass, hiding work that was still queued.
  const stored = db.prepare('SELECT total_count FROM contact_enrich_jobs WHERE id = ?').get(jobId)?.total_count || 0;
  if (stored > 0) return stored;
  return db.prepare('SELECT COUNT(*) AS cnt FROM contact_enrich_results WHERE job_id = ?').get(jobId)?.cnt || 0;
}

function finishJob(db, jobId) {
  const job = setStatus(db, jobId, 'completed');
  const done = jobWithProgress(db, job);
  notify(db.workspaceName, `Обогащение #${jobId} завершено: ${done.summarized} конспектов, ${done.failed} без данных.`, {
    key: `enrich-done:${jobId}`
  }).catch(() => {});
  return { task: null, job_completed: jobId, message: `Обогащение #${jobId} завершено`, job: done };
}

router.get('/task', async (req, res) => {
  try {
    res.json(await getEnrichTask(req.db));
  } catch (e) {
    console.error('[ContactEnrich] task error:', e.message);
    res.status(500).json({ task: null, error: e.message });
  }
});

router.post('/task/:id/scraped', async (req, res) => {
  const db = req.db;
  const job = db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Задача не найдена' });

  const profiles = Array.isArray(req.body?.profiles) ? req.body.profiles : [];
  const update = db.prepare(`
    UPDATE contact_enrich_results
    SET scraped = 1, bio = ?, full_name = COALESCE(NULLIF(?, ''), full_name),
        follower_count = ?, post_count = ?, external_url = ?, is_private = ?,
        posts_json = ?, error = NULL
    WHERE job_id = ? AND username = ?
  `);
  const markFailed = db.prepare(
    `UPDATE contact_enrich_results SET scraped = 1, summarized = 1, error = ? WHERE job_id = ? AND username = ?`
  );
  const resetLead = db.prepare('UPDATE leads SET enrich_status = ?, enrich_error = ? WHERE username = ?');

  let ok = 0;
  let failed = 0;
  const failedDetail = [];
  db.transaction(() => {
    for (const p of profiles) {
      const username = normalizeUsername(p?.username);
      if (!username) continue;

      const posts = Array.isArray(p?.posts) ? p.posts.filter(Boolean).slice(0, ENRICH_LIMITS.MAX_POSTS_PER_PROFILE * 2) : [];
      // A profile with neither a bio nor a single post caption has nothing to
      // summarize. Private accounts without a bio fall here, and they are the
      // bulk of a cold list — treating them as failures keeps them out of the
      // "needs a note" filter instead of filling it with empty notes.
      const hasMaterial = !!String(p?.bio || '').trim() || posts.length > 0;

      if (p?.error || !hasMaterial) {
        const reason = p?.error ? String(p.error).slice(0, 200) : 'Нет публичных данных (приватный профиль или пустое био)';
        markFailed.run(reason, job.id, username);
        resetLead.run('failed', reason, username);
        failedDetail.push(`@${username} — ${reason}`);
        failed++;
        continue;
      }

      update.run(
        String(p.bio || '').slice(0, 1000) || null,
        p.full_name || '',
        Number.isFinite(Number(p.follower_count)) ? Number(p.follower_count) : null,
        Number.isFinite(Number(p.post_count)) ? Number(p.post_count) : null,
        p.external_url || null,
        p.is_private ? 1 : 0,
        JSON.stringify(posts),
        job.id,
        username
      );
      ok++;
    }
  })();

  // Per-contact reasons are the difference between "1 без данных" and a line
  // that says whether the account is private, rate-limited, or simply empty.
  if (failedDetail.length) {
    console.log(`[ContactEnrich] Job #${job.id} — без данных (${failed}):\n  ${failedDetail.join('\n  ')}`);
  }
  console.log(`[ContactEnrich] Job #${job.id} ← extension: прочитано ${ok}, без данных ${failed}`);

  db.prepare(`
    UPDATE contact_enrich_jobs SET scraped_count = ?, consecutive_errors = 0, phase = 'summarize',
      updated_at = ?, last_progress_at = ?
    WHERE id = ?
  `).run(
    db.prepare('SELECT COUNT(*) AS cnt FROM contact_enrich_results WHERE job_id = ? AND scraped = 1').get(job.id).cnt,
    getMoscowISO(), nowUtc(), job.id
  );
  spendBudget(db, profiles.length);

  // Generate while the extension is resting between batches. If this throws the
  // scraped rows are already banked and the next poll retries.
  let summarized = 0;
  try {
    summarized = await runSummaryPass(db, job.id, 2);
  } catch (e) {
    console.error(`[ContactEnrich] Job #${job.id} inline summary failed:`, e.message);
  }

  res.json({ success: true, ok, failed, summarized });
});

router.post('/task/:id/error', (req, res) => {
  const db = req.db;
  const job = db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Задача не найдена' });

  const { error_message, rate_limited } = req.body || {};
  const errors = (job.consecutive_errors || 0) + 1;

  // Rate limiting is expected and self-healing: the job goes quiet and resumes
  // on the next poll rather than dying, which is what keeps a background run
  // safe to leave alone.
  const shouldPause = errors >= ENRICH_LIMITS.MAX_CONSECUTIVE_ERRORS && !rate_limited;
  if (shouldPause) {
    setStatus(db, job.id, 'paused', { error_message: String(error_message || 'Слишком много ошибок подряд') });
  } else {
    db.prepare('UPDATE contact_enrich_jobs SET consecutive_errors = ?, error_message = ?, updated_at = ?, last_progress_at = ? WHERE id = ?')
      .run(errors, rate_limited ? null : String(error_message || '').slice(0, 200), getMoscowISO(), nowUtc(), job.id);
  }

  res.json({ success: true, paused: shouldPause, consecutive_errors: errors });
});

export default router;
