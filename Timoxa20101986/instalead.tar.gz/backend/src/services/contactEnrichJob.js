// Job creation shared by the batch endpoint and the single-contact shortcut, so
// "ИИ-обогатить" on a selection and on one row produce the identical job shape.
// Duplicating this transaction is how the two paths would drift — the shortcut
// would skip lead creation and the note would land nowhere.

import { getMoscowISO } from './schedulerService.js';
import { ENRICH_BATCH, ENRICH_LIMITS } from './contactEnrichService.js';

export function createEnrichJob(db, { usernames, runMinutes = 60 }) {
  const unique = [...new Set(
    (usernames || [])
      .map(u => String(u || '').trim().replace(/^@/, '').toLowerCase())
      .filter(Boolean)
  )];
  if (!unique.length) {
    console.warn('[ContactEnrich] createEnrichJob called with no usable usernames — no job created');
    return null;
  }

  const nameOf = db.prepare('SELECT full_name FROM contacts WHERE username = ?');

  const jobId = db.transaction(() => {
    const result = db.prepare(
      'INSERT INTO contact_enrich_jobs (status, phase, total_count, run_minutes) VALUES (?, ?, ?, ?)'
    ).run('pending', 'scrape', unique.length, runMinutes);
    const id = Number(result.lastInsertRowid);

    const insertResult = db.prepare(
      'INSERT OR IGNORE INTO contact_enrich_results (job_id, username) VALUES (?, ?)'
    );
    // Contacts added by hand exist only in `contacts`; the send path joins
    // `leads`, so the row has to exist before a note can be written to it.
    // enrich_status is set on the insert too — leaving it to the column default
    // would make a brand-new lead read as "never enriched" while its job is
    // queued, and the Contacts filter would hide it.
    const upsertLead = db.prepare(`
      INSERT INTO leads (username, full_name, enrich_status) VALUES (?, ?, 'queued')
      ON CONFLICT(username) DO UPDATE SET enrich_status = 'queued', enrich_error = NULL
    `);
    const touchContact = db.prepare('UPDATE contacts SET updated_at = ? WHERE username = ?');

    for (const username of unique) {
      insertResult.run(id, username);
      upsertLead.run(username, nameOf.get(username)?.full_name || null);
      touchContact.run(getMoscowISO(), username);
    }
    return id;
  })();

  const created = db.prepare('SELECT * FROM contact_enrich_jobs WHERE id = ?').get(jobId);
  console.log(
    `[ContactEnrich] Job #${jobId} created: ${unique.length} contacts, block ${runMinutes} min` +
    (unique.length <= 5 ? ` (${unique.join(', ')})` : '')
  );
  return created;
}

// The decorated view the UI reads. Lives here rather than in a route so the
// batch endpoint and the single-contact shortcut answer with an identical
// shape — a raw row from one and a decorated one from the other is how a
// caller ends up reading progress.percent off a missing field.
export function jobWithProgress(db, job) {
  if (!job) return null;
  const counts = db.prepare(`
    SELECT
      SUM(CASE WHEN summarized = 1 THEN 1 ELSE 0 END) AS summarized,
      SUM(CASE WHEN summarized = 1 AND (summary IS NULL OR summary = '') THEN 1 ELSE 0 END) AS empty_notes,
      SUM(CASE WHEN error IS NOT NULL AND error != '' THEN 1 ELSE 0 END) AS failed,
      SUM(CASE WHEN scraped = 0 AND summarized = 0 THEN 1 ELSE 0 END) AS pending,
      COUNT(*) AS total_rows
    FROM contact_enrich_results WHERE job_id = ?
  `).get(job.id);

  // "Done" means the row is closed, not that a note exists. A row is closed
  // once it has been summarized — the AI pass sets summarized=1 even on the
  // failure paths (markFailed, "the model returned no note"), so summing
  // `summarized + failed` counted the same row twice: a private profile with no
  // bio reported as both "Готово 1" and "Без данных 1", and pushed the bar past
  // 100%.
  const totalRows = counts?.total_rows || 0;
  const failed = counts?.failed || 0;
  const pending = counts?.pending || 0;
  const done = totalRows - pending;
  // Jobs created before total_count was stored keep 0 there. Falling back to the
  // number of real rows is what stops such a job from reading as an eternal 0%.
  const total = Math.max(job.total_count || 0, totalRows);

  return {
    ...job,
    total: total || job.total_count || 0,
    scraped: counts?.summarized || 0,
    summarized: (counts?.summarized || 0) - (counts?.empty_notes || 0),
    empty_notes: counts?.empty_notes || 0,
    failed,
    pending,
    done,
    percent: total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0,
    // Rough wall-clock estimate from the server-side pacing, so the UI can tell
    // the user whether this is a two-minute job or a two-hour one before they
    // commit to it.
    estimated_minutes: estimateMinutes(total || job.total_count || 0)
  };
}

function estimateMinutes(total) {
  const perProfile = (ENRICH_LIMITS.DELAY_MIN_MS + ENRICH_LIMITS.DELAY_MAX_MS) / 2000 / 60;
  const blocks = Math.ceil(total / ENRICH_LIMITS.BATCH_SIZE);
  const perBlockRest = (ENRICH_LIMITS.COOLDOWN_MIN_MS + ENRICH_LIMITS.COOLDOWN_MAX_MS) / 2000 / 60;
  return Math.max(1, Math.round(total * perProfile + Math.max(0, blocks - 1) * perBlockRest));
}