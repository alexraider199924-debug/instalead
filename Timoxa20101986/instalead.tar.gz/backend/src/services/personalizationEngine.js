// ---------------------------------------------------------------------------
// Personalization engine.
//
// One place where a DM opener is built, judged and retried. The previous code
// had three near-identical generators with three drifting prompt bodies and a
// guardrail array that was declared and never used; the business context read
// from ai_business_context stopped at the route and never reached the model.
//
// The order below is the order a message travels:
//   business context -> profile intelligence -> prompt -> quality gate -> retry.
// ---------------------------------------------------------------------------

import { callOpenRouter } from './aiService.js';
import { parseFirstName } from './nameParser.js';
import { normalizeAgentContext, policyInstructions } from './offerContext.js';
import { ENRICH_VERSION } from './contactEnrichService.js';

// The guardrails that were previously declared but unused. They constrain the
// model, and the quality gate re-checks the two that are mechanically testable.
const STANDARDS = [
  'Используй только подтверждённые данные из контекста бизнеса и профиля лида. Ничего не выдумывай.',
  'Не выдавай отправителя за другого человека и не создавай впечатление личного знакомства.',
  'Не скрывай коммерческий характер предложения и сохраняй смысл оффера и CTA из шаблона.',
  'Используй ровно одну конкретную деталь из bio или постов, если такая деталь есть. Если данных нет — не имитируй знакомство.',
  'Если шаблон содержит обман, давление или просьбу обойти правила платформы, не усиливай это.',
  'Верни только готовый текст сообщения: 2-4 коротких предложения, без эмодзи (если их нет в шаблооне) и без длинного тире.'
];

// Phrases that make a DM read as automated. Enforced after generation, because
// listing them in the prompt alone reliably leaks through anyway.
const BANNED_OPENERS = [
  'hi there', 'hey there', 'hello there',
  'привет', 'здравствуйте', 'добрый день', 'доброе утро',
  'hola', 'bonjour', 'ciao', 'hallo'
];

const BANNED_PHRASES = [
  'i love what you do', 'your content is amazing', "you're incredible",
  'love your content', 'just wanted to reach out', 'saw your profile',
  'seemed interesting', 'caught my eye', 'love what you see',
  'мне нравится твой контент', 'понравились твои посты', 'заинтересовал твой профиль',
  'хотел написать', 'увидел твой профиль'
];

const LANG_NAMES = {
  ru: 'русском', en: 'английском', es: 'испанском', de: 'немецком',
  fr: 'французском', it: 'итальянском', pt: 'портагальском', nl: 'нидерландском',
  pl: 'польском', tr: 'турецком', ar: 'арабском', hi: 'хинди'
};

const DEFAULT_LANG = 'en';

function pickLang(...candidates) {
  for (const code of candidates) {
    if (code && LANG_NAMES[code]) return code;
  }
  return DEFAULT_LANG;
}

// ---------------------------------------------------------------------------
// Business context
// ---------------------------------------------------------------------------

// The field contract, defaults and prompt wording all live in offerContext.js.
// This function is only the name the rest of the codebase already imports; it
// stays so existing call sites keep working while returning the richer,
// policy-aware shape.
export function buildBusinessContext(agentContext) {
  return normalizeAgentContext(agentContext);
}

function trim(value, max) {
  const s = String(value ?? '').replace(/\s+/g, ' ').trim();
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

// ---------------------------------------------------------------------------
// Profile intelligence
// ---------------------------------------------------------------------------

// The previous implementation detected topics with Russian-and-English-only
// regexes, so a Spanish fitness lead produced no insight at all. These cover
// the six supported languages for the categories that actually drive a hook.
const TOPIC_KEYWORDS = {
  fitness: /\b(gym|workout|work out|fitness|trainer|training|run|running|marathon|crossfit|yoga|gimnasio|entrenamiento|fitness|gymnasium|entrainement|palestra|allenamento)\b|фитнес|трениров|спорт|качок|зал/i,
  food: /\b(food|recipe|cook|cooking|bakery|chef|restaurant|eating|vegetarian|cocina|receta|gourmet|küche|rezept|cucina|ricetta)\b|еда|рецепт|готов|кухн/i,
  travel: /\b(travel|trip|adventure|journey|explore|tourism|viaje|aventura|reise|abenteuer|viaggio)\b|путеш|туризм/i,
  business: /\b(business|entrepreneur|startup|founder|agency|business|agency|emprendedor|negocio|gruender|unternehmen|imprenditore)\b|бизнес|предпринимат|стартап/i,
  beauty: /\b(beauty|makeup|skincare|cosmetic|hair|nail|spa|belleza|maquillaje|piel|beauty|makeup|haarpflege|makeup|beauty)\b|красот|макияж|космет/i,
  tech: /\b(tech|technology|software|app|developer|coding|saas|tecnologia|software|technologie|software)\b|технолог|разработ/i,
  creator: /\b(content|creator|vlogger|youtube|blogger|influencer|tiktok|reels|creador|contenido|content)\b|блог|влогер|контент/i,
  family: /\b(family|mama|mom|mother|дети|семья|мама|мать)\b/,
  fashion: /\b(fashion|style|outfit|clothing|moda|ropa|moda|kleidung)\b|мода|стиль|одежд/i,
  auto: /\b(auto|cars|car|driving|motorsport|авто|машин|автомобил)\b/
};

const AUDIENCE_BANDS = [
  [100000, 'крупный инфлюенсер (100k+)'],
  [50000, 'мега-блогер (50k+)'],
  [10000, 'микро-инфлюенсер (10k+)'],
  [1000, 'растущий контент-мейкер (1k+)'],
  [0, 'активный пользователь']
];

export function buildProfileIntelligence(profileData, lead) {
  const pd = profileData || {};
  const posts = Array.isArray(pd.posts) ? pd.posts.filter(Boolean) : [];
  const bio = String(pd.bio || lead?.bio || '').trim();

  // The note produced by contact enrichment. When it exists it is the whole
  // point of the two-stage design: the model already read this profile once,
  // paid for it, and wrote down what actually matters. Re-deriving themes with
  // the keyword tables below would throw that away and replace a considered
  // read with regex buckets.
  const summary = String(lead?.profile_summary || '').trim();
  const meta = readSummaryMeta(lead?.profile_summary_meta);

  // Hooks only exist from ENRICH_VERSION 2 onward, and a note written by an
  // older prompt version was graded against a different idea of what a hook
  // is. Using its (absent or differently-shaped) hooks would silently degrade
  // the message, so they are ignored rather than guessed at.
  const hooks = meta.version === ENRICH_VERSION && Array.isArray(meta.hooks)
    ? meta.hooks.filter(h => typeof h === 'string' && h.trim().length > 2).slice(0, 3)
    : [];

  const facts = [];
  const hooksBlock = [];

  if (summary) {
    facts.push(`КОНСПЕКТ ПРОФИЛЯ (подготовлен заранее, это главный источник):\n${trim(summary, 700)}`);
  }

  if (bio) facts.push(`БИО: ${trim(bio, 300)}`);

  const found = new Set();
  for (const post of [...posts, bio].slice(0, 12)) {
    for (const [topic, re] of Object.entries(TOPIC_KEYWORDS)) {
      if (re.test(post)) found.add(topic);
    }
  }
  // Themes inferred by keyword matching are a weak signal next to a written
  // summary, and they are actively harmful when they contradict it (a
  // "fitness" account that sells courses for finance). Shown only as a hint.
  if (found.size && !summary) facts.push(`ТЕМЫ КОНТЕНТА: ${[...found].join(', ')}`);

  const followers = Number(pd.followers) || 0;
  if (followers > 0) {
    const band = AUDIENCE_BANDS.find(([min]) => followers >= min)[1];
    facts.push(`АУДИТОРИЯ: ${followers} подписчиков (${band})`);
  }

  if (lead?.niche) facts.push(`НИША: ${trim(lead.niche, 120)}`);

  // One verbatim line from the profile is worth more to the model than any
  // summary of it, because it is the only part it cannot paraphrase into a
  // generic compliment.
  if (hooks.length) {
    hooksBlock.push(`ТРИ КРЮЧКА — конкретные зацепки, отобранные из этого профиля. Возьми ОДИН и начни с него своими словами:\n${hooks.map((h, i) => `${i + 1}. ${trim(h, 90)}`).join('\n')}\nНе используй два сразу — это перечисление, а не личное обращение.`);
  }

  if (summary) {
    hooksBlock.push('ОПИРАЙСЯ НА КОНСПЕКТ ВЫШЕ. Бери оттуда конкретные детали и вплетай их в оффер. Не пересказывай конспект целиком и не перечисляй факты списком.');
  } else if (posts.length) {
    hooksBlock.push(`ДОСТУПНЫЕ ЦИТАТЫ ИЗ ПРОФИЛЯ (используй максимум одну, своими словами):\n${posts.slice(0, 3).map((p, i) => `${i + 1}. ${trim(p, 180)}`).join('\n')}`);
  } else if (bio) {
    hooksBlock.push(`ЕДИНСТВЕННАЯ ДОСТУПНАЯ ДЕТАЛЬ — БИО: ${trim(bio, 300)}\nЕсли из неё нельзя вывести честный повод для личного сообщения, напиши нейтральное сообщение БЕЗ имитации знакомства.`);
  } else {
    hooksBlock.push('ДАННЫХ О ПРОФИЛЕ НЕТ. Пиши нейтральное сообщение от лица бизнеса. НЕ придумывай интересы, посты, профессию и общие интересы.');
  }

  return {
    text: facts.length ? facts.join('\n') : '',
    hooks: hooksBlock.join('\n\n'),
    hasAnyData: Boolean(summary || bio || posts.length),
    // The grounding check below used to require a verbatim post quote, which
    // made a well-personalized message fail whenever enrichment had run and
    // the raw posts were no longer in hand. It now accepts the summary.
    summary,
    hooksList: hooks,
    topics: [...found],
    quotes: posts.slice(0, 3).map(p => trim(p, 180)).filter(Boolean),
    followers
  };
}

function readSummaryMeta(raw) {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

// ---------------------------------------------------------------------------
// Prompt
// ---------------------------------------------------------------------------

const STYLE_DIRECTIVES = {
  friendly: 'Тон тёплый и доброжелательный, но сдержанный.',
  neutral: 'Тон естественный и нейтральный.',
  business: 'Тон деловой, конкретный, без сюсюканья.',
  custom: ''
};

export function buildPrompt({ businessContext, intel, template, lead, lang, style, customPrompt }) {
  const langName = LANG_NAMES[lang] || 'английском';
  const policy = businessContext?.policy || { opening: 'profile_first', greeting: 'auto', length: 420, tone: 'neutral' };

  // A campaign may override the agent's tone with its own style. An explicit
  // custom instruction always wins. Otherwise the AI Agent's own voice wins:
  // campaigns store personalization_style='neutral' by default, and letting
  // that default through appended "тон нейтральный" to every prompt even when
  // the sender had described a specific voice in the AI Agent tab — the agent's
  // voice was collected and then diluted back into nothing.
  const agentHasVoice = Boolean(businessContext?.policy?.hasStyle);
  const campaignStyleText = style === 'custom'
    ? trim(customPrompt, 500)
    : STYLE_DIRECTIVES[style] || '';
  const styleText = style === 'custom'
    ? campaignStyleText
    : (agentHasVoice ? '' : campaignStyleText);

  const firstName = parseFirstName(lead?.full_name, lead?.username) || '';

  const systemPrompt = `Ты пишешь первые DM в Instagram от лица компании. Твоё сообщение прочитает живой человек и решит за секунды, отвечать ли ему.

ПИШИ СТРОГО НА ${langName.toUpperCase()} ЯЗЫКЕ.

ТВОЯ ЗАДАЧА: взять оффер ниже и встроить его в одно личное обращение к конкретному человеку. Не «реклама с деталью», а «человек, которому видно, что вы зашли в его профиль и поняли, чем он занимается».

ЧТО ДЕЛАЕТ ХОРОШЕЕ СООБЩЕНИЕ:
- Первая фраза — про этого человека или про его профиль, а не «Привет» и не название продукта
- Ровно одна-две конкретные детали из конспекта, вплетённые в текст, а не перечисленные списком
- Оффер чувствуется в сообщении, но не выглядит как вставленная реклама
- Читается как сообщение от человека, а не как шаблон с подставленным именем
- Заканчивается одним простым вопросом или предложением, на которое легко ответить
- 2-4 коротких предложения, примерно до ${policy.length} символов

ЖЁСТКИЕ ПРАВИЛА:
- Никаких вступлений вроде «Привет», «Hi there» — так начинают боты
- Никаких комплиментов вроде «обожаю твой контент» — это считывается как спам
- Не задавай вопрос, ответ на который уже есть в био или постах
- Не упоминай количество подписчиков и не хватайся этим
- Если данных о профиле нет — пиши от лица бизнеса, без выдуманных интересов
${businessContext?.guardrails ? `\nЗАПРЕТЫ ОТПРАВИТЕЛЯ (нарушение — ошибка):\n${businessContext.guardrails}` : ''}

${STANDARDS.map((s, i) => `${i + 1}. ${s}`).join('\n')}`;

  const sections = [
    `ЯЗЫК: ${langName}`,
    businessContext?.offer ? `ЧТО МЫ ПРЕДЛАГАЕМ:\n${businessContext.offer}` : '',
    businessContext?.style ? `КАК ГОВОРИТ ОТПРАВИТЕЛЬ:\n${businessContext.style}` : '',
    intel?.text ? `ЧТО ИЗВЕСТНО О ПОЛУЧАТЕЛЕ:\n${intel.text}` : '',
    intel?.hooks ? `ОПОРЫ ДЛЯ ПЕРСОНАЛЬНОГО ПОВОДА:\n${intel.hooks}` : '',
    `ПОЛУЧАТЕЛЬ:\nUsername: @${lead?.username || 'unknown'}\nИмя: ${firstName || 'не указано'}`,
    styleText ? `ДОПОЛНИТЕЛЬНЫЙ СТИЛЬ ОТПРАВИТЕЛЯ:\n${styleText}` : '',
    policyInstructions(policy).map(r => `- ${r}`).join('\n'),
    template ? `ОСНОВА СООБЩЕНИЯ (переформулируй и встрой в личный контекст, не копируй):\n${trim(template, 600)}` : '',
    'Напиши готовое сообщение. Только текст сообщения, без комментариев и объяснений.'
  ].filter(Boolean);

  return { systemPrompt, userPrompt: sections.join('\n\n') };
}

// ---------------------------------------------------------------------------
// Quality gate
// ---------------------------------------------------------------------------

// Returns a list of human-readable problems. Empty means the message passed.
// A failed gate does not discard the message — it feeds the problems back so
// the next attempt fixes exactly what was wrong.
export function runQualityGate({ text, lang, intel, template, businessContext }) {
  const issues = [];
  const body = String(text || '').trim();

  if (!body) {
    issues.push('сообщение пустое');
    return issues;
  }

  const policy = businessContext?.policy || { length: 420, greeting: 'auto' };

  // The ceiling comes from the AI Agent tab, with headroom for the model to
  // overshoot slightly — a retry told "exactly 420" produces stunted text.
  const maxLen = Math.round((policy.length || 420) * 1.35);
  const len = body.length;
  if (len < 60) issues.push(`слишком короткое (${len} символов) — нет содержания`);
  if (len > maxLen) issues.push(`слишком длинное (${len} символов) — в DM не читают, максимум ${policy.length}`);

  const lower = body.toLowerCase();
  const openerHit = BANNED_OPENERS.find(p => lower.startsWith(p));
  if (openerHit) {
    issues.push(policy.greeting === 'name'
      ? `начинается с шаблонного «${openerHit}», хотя по настройке нужно начать с имени`
      : `начинается с шаблонного «${openerHit}»`);
  }

  const phraseHit = BANNED_PHRASES.find(p => lower.includes(p));
  if (phraseHit) issues.push(`содержит шаблонную фразу «${phraseHit}»`);

  if (/—/.test(body)) issues.push('использовано длинное тире');

  // The one check that actually distinguishes personalization from a mail merge:
  // material from the profile has to survive into the message. Grounding is
  // checked against the HOOKS first when they exist: three fragments of five
  // to seven words are a far sharper target than 90 words of prose, so a
  // message that reaches for a general sentence ("эксперт в своей нише") is
  // rejected while one that reaches for "разбирает чужие ошибки в забегах"
  // passes. Exact word matching is unusable as the primary test — Russian
  // inflects, and "разбирает" shares no equal token with "разбор" — hence the
  // character n-grams, loose on purpose because a false accept sends a slightly
  // generic message while a false reject burns a paid retry.
  if (intel?.hasAnyData) {
    const hooked = (intel.hooksList || []).some(h => sharedGrams(h, body, 4) >= 1);
    const grounded = hooked
      || (intel.summary && sharedGrams(intel.summary, body, 4) >= 1)
      || (intel.quotes.length && intel.quotes.some(q => overlap(q, body) >= 0.34))
      || (!intel.summary && intel.text && sharedWordCount(intel.text, body) >= 2);
    if (!grounded) {
      issues.push(hooked || intel.summary
        ? 'сообщение не опирается на конспект профиля — это шаблон'
        : 'нет ни одной конкретной детали из профиля — это шаблон');
    }
  }

  // The mirror failure: the model handing back the campaign template with a
  // name dropped in. Cheap to detect and the reason most cold DMs feel mass-
  // produced, so it is checked explicitly rather than inferred from the
  // personalization check above.
  if (template && overlap(template, body) >= 0.55) {
    issues.push('сообщение почти дословно повторяет шаблон — это не персонализация');
  }

  // A DM with no ask is a DM with no reason to reply, which is the one thing
  // this system exists to prevent. Either it asks something, or the intent of
  // the configured CTA survived into the text — the same n-gram test used for
  // grounding, because "скиньте профиль" has to be allowed to answer "скиньте
  // профиль в директ". A keyword list was tried first and accepted any message
  // containing the word "интересно", which is not an ask.
  const cta = String(businessContext?.map?.offer_cta || '').trim();
  if (cta) {
    const asksSomething = /[?？]/.test(body) || sharedGrams(cta, body, 4) >= 1;
    if (!asksSomething) {
      issues.push('нет призыва к действию — добавь один простой вопрос из блока «ЧТО ПРОСИМ В ОТВЕТ»');
    }
  }

  if (!/[.!?]/.test(body)) issues.push('нет знака конца предложения');

  return issues;
}

function tokens(value) {
  return String(value || '').toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(w => w.length > 3);
}

function overlap(source, target) {
  const a = new Set(tokens(source));
  if (!a.size) return 0;
  let hit = 0;
  for (const w of new Set(tokens(target))) if (a.has(w)) hit++;
  return hit / a.size;
}

function sharedWordCount(source, target) {
  const a = new Set(tokens(source));
  let hit = 0;
  for (const w of new Set(tokens(target))) if (a.has(w)) hit++;
  return hit;
}

// Distinct n-grams shared between two texts. Character-based rather than
// word-based on purpose: it has to work for Russian inflection and for
// languages this system does not model at all.
function sharedGrams(source, target, n) {
  const grams = new Set();
  for (const word of tokens(source)) {
    if (word.length < n) continue;
    for (let i = 0; i + n <= word.length; i++) grams.add(word.slice(i, i + n));
  }
  if (!grams.size) return 0;
  let hit = 0;
  for (const word of new Set(tokens(target))) {
    if (word.length < n) continue;
    for (let i = 0; i + n <= word.length; i++) {
      if (grams.has(word.slice(i, i + n))) { hit++; break; }
    }
  }
  return hit;
}

export function detectLangCode(text) {
  const value = String(text || '').toLowerCase();
  const marks = [
    ['ru', /[а-яё]/],
    ['es', /[ñáéíóú¿¡]/],
    ['de', /[äöüß]/],
    ['fr', /[àâçéèêëîïôûùœ]/],
    ['it', /[àèéìòù]/],
    ['pt', /[ãõçáéíóúâê]/]
  ];
  for (const [code, re] of marks) if (re.test(value)) return code;
  return 'en';
}

// ---------------------------------------------------------------------------
// Orchestration
// ---------------------------------------------------------------------------

const ATTEMPTS = 2;

export async function generatePersonalizedMessage(db, {
  messageTemplate = '',
  lead = {},
  profileData = null,
  agentContext = [],
  style = 'neutral',
  customPrompt = '',
  extraInstruction = '',
  lang,
  maxTokens = 420
}) {
  const businessContext = buildBusinessContext(agentContext);
  const intel = buildProfileIntelligence(profileData, lead);

  // Language precedence: explicit call > the AI Agent's language setting when
  // it is not "auto" > whatever language the message template is written in.
  // "auto" means "match the recipient", which is the mode-language detector
  // already approximates — guessing from a Russian template used to force
  // Russian onto a Spanish account whose profile is entirely Spanish.
  const configured = businessContext?.policy?.language;
  const targetLang = pickLang(
    lang,
    configured && configured !== 'auto' ? configured : undefined,
    detectLangCode(messageTemplate)
  );

  const { systemPrompt, userPrompt } = buildPrompt({
    businessContext, intel, template: messageTemplate, lead, lang: targetLang, style, customPrompt
  });

  const basePrompt = extraInstruction ? `${userPrompt}\n\nДОПОЛНИТЕЛЬНАЯ ИНСТРУКЦИЯ: ${trim(extraInstruction, 300)}` : userPrompt;

  let lastIssues = [];
  let text = '';
  for (let attempt = 0; attempt < ATTEMPTS; attempt++) {
    const prompt = attempt === 0 || !lastIssues.length
      ? basePrompt
      : `${basePrompt}\n\nПРЕДЫДУЩАЯ ПОПЫТКА НЕ ПРОШЛА ПРОВЕРКУ:\n- ${lastIssues.join('\n- ')}\n\nИсправь ровно эти проблемы и верни только исправленное сообщение.`;

    text = await callOpenRouter(db, systemPrompt, prompt, maxTokens);

    const issues = runQualityGate({ text, lang: targetLang, intel, template: messageTemplate, businessContext });
    const wrongLang = detectLangCode(text) !== targetLang && targetLang !== 'en';
    if (wrongLang) issues.push(`сообщение не на ${LANG_NAMES[targetLang]} языке`);

    if (!issues.length) return text;
    lastIssues = issues;
    console.warn(`[Personalization] attempt ${attempt + 1} rejected: ${issues.join('; ')}`);
  }

  // Both attempts failed the gate. The message still went through generation,
  // so returning it beats dropping the send — but say so in the log rather than
  // pretending it passed.
  console.warn('[Personalization] quality gate not satisfied, sending best effort');
  return text;
}

// ---------------------------------------------------------------------------
// Compatibility wrappers.
//
// The route layer and older stored campaigns still branch between these three
// entry points. They now share one prompt builder and one quality gate instead
// of carrying three copies of both. The three names are kept so existing calls
// keep working; new callers should use generatePersonalizedMessage directly.
// ---------------------------------------------------------------------------

export async function generateCampaignPersonalizedMessage(db, {
  messageTemplate, lead, profileData, agentContext = [], style = 'neutral', customPrompt = ''
}) {
  return generatePersonalizedMessage(db, {
    messageTemplate, lead, profileData, agentContext, style, customPrompt
  });
}

export async function generateFullPersonalizedMessage(db, {
  messageTemplate, lead, profileData, agentContext = []
}) {
  return generatePersonalizedMessage(db, {
    messageTemplate, lead, profileData, agentContext, style: 'friendly'
  });
}

export async function personalizeMessage(db, {
  messageTemplate, aiPrompt, lead, profileData, agentContext = []
}) {
  // The legacy path supplied its own instruction instead of a style. Keeping it
  // as an explicit instruction preserves old campaigns verbatim.
  return generatePersonalizedMessage(db, {
    messageTemplate, lead, profileData, agentContext,
    style: 'custom', customPrompt: aiPrompt || ''
  });
}