// ---------------------------------------------------------------------------
// Profile enrichment — the first of the two AI calls.
//
// One job of this service: turn raw Instagram profile data into the two-tier
// note the send step reads later.
//
//   summary  — ≤ summary_max_words words, starts with "В профиле". What the
//              model should *know* about this person.
//   hooks    — exactly three fragments of 5–7 words. What it should *say*.
//
// The split exists because a single 90-word paragraph is good at the first job
// and bad at the second. Given only a paragraph, a model writing the DM drifts
// toward the summary's most general sentences — "эксперт в своей нише" — which
// is the least personalizable part of it. Given three short concrete fragments,
// it reaches for the specific one instead: "разбирает чужие ошибки в забегах".
// The hooks are also what the send-side quality gate grounds against, which is
// a far sharper test than comparing against 90 words of prose.
// ---------------------------------------------------------------------------

import { callOpenRouter, parseJsonReply } from './aiService.js';
import { normalizeAgentContext } from './offerContext.js';

// Ten summaries per call. Much smaller than the scoring batch: each summary is
// ~90 words of considered prose plus three hooks, so a large batch degrades the
// per-profile care far faster than it saves request overhead.
export const ENRICH_BATCH = 10;

export const HOOK_COUNT = 3;
export const HOOK_MIN_WORDS = 5;
export const HOOK_MAX_WORDS = 7;

// Bumping this marks every stored summary as stale. The send path compares it
// before trusting a note, so an old prompt's output never silently becomes the
// basis of a message written to a new prompt's spec.
export const ENRICH_VERSION = 2;

// Pacing is declared next to the batch size it derives from, so the two cannot
// drift: the route reads these, not local copies.
export const ENRICH_LIMITS = {
  DELAY_MIN_MS: 1200,
  DELAY_MAX_MS: 2800,
  // Rest between batches, not between profiles. Reading profiles back to back
  // is what triggers Instagram's checkpoint; the pauses are what keep the
  // account alive.
  COOLDOWN_MIN_MS: 20000,
  COOLDOWN_MAX_MS: 45000,
  BATCH_SIZE: ENRICH_BATCH,
  DEFAULT_RUN_MINUTES: 60,
  MAX_RUN_MINUTES: 720,
  MAX_CONTACTS_PER_JOB: 1000,
  MAX_CONSECUTIVE_ERRORS: 3,
  // How long an untouched job waits before being declared abandoned. Much
  // longer than a run_minutes block on purpose: the block expiry is the normal
  // stop, this is the "user closed the laptop a week ago" case.
  DISCONNECT_MINUTES: 360,
  MAX_POSTS_PER_PROFILE: 8
};

const LANG_NAMES = {
  ru: 'русском', en: 'английском', es: 'испанском', de: 'немецком',
  fr: 'французском', it: 'итальянском', pt: 'портагальском', nl: 'нидерландском',
  pl: 'польском', tr: 'турецком', ar: 'арабском', hi: 'хинди'
};

const wordCount = text => String(text || '').trim().split(/\s+/).filter(Boolean).length;

// Cuts at a sentence boundary so an over-long summary loses its last clause
// rather than ending mid-word. The prompt already asks for the cap; this is the
// enforcement, because a model asked nicely still overshoots.
export function clampWords(text, max) {
  const value = String(text || '').replace(/\s+/g, ' ').trim();
  if (wordCount(value) <= max) return value;

  const words = value.split(' ');
  let cut = '';
  for (let i = 0; i < Math.min(words.length, max); i++) {
    const candidate = words.slice(0, i + 1).join(' ');
    if (/[.!?…]$/.test(candidate)) cut = candidate;
    // A long run without a sentence end means the model wrote a run-on; fall
    // back to the hard cap rather than returning nothing.
    if (i === max - 1) cut = cut || candidate;
  }
  return cut.replace(/[ ,;:]+$/, '');
}

// Hooks are the load-bearing part, so they are normalized hard: exactly three,
// each inside the word band, none of them a copy of the summary's own phrasing.
// A hook that is too short ("бег") passes a word-count check but gives the send
// step nothing to work with, so short hooks are padded out by rejection — the
// model is asked again rather than accepted as-is.
// Word-band enforcement for hooks. Exported so the contract is testable without
// a model in the loop.
export function normalizeHook(raw) {
  const value = String(raw || '').replace(/^[\s"'«»\-–—*•]+|[\s"'«».,;:]+$/g, '').replace(/\s+/g, ' ').trim();
  if (!value) return null;
  const words = value.split(' ');
  if (words.length > HOOK_MAX_WORDS) return words.slice(0, HOOK_MAX_WORDS).join(' ');
  if (words.length < HOOK_MIN_WORDS) return null;
  return value;
}

export function normalizeHooks(list) {
  const out = [];
  for (const raw of Array.isArray(list) ? list : []) {
    const hook = normalizeHook(raw);
    if (hook && !out.some(h => h.toLowerCase() === hook.toLowerCase())) out.push(hook);
    if (out.length === HOOK_COUNT) break;
  }
  return out;
}

// ---------------------------------------------------------------------------
// Prompt
// ---------------------------------------------------------------------------

// Exported so the prompt contract is testable without spending a call: the
// JSON shape and the word band are load-bearing for the send step and cannot
// be allowed to drift by accident.
export function buildSystemPrompt({ summaryLang, maxWords }) {
  const langName = LANG_NAMES[summaryLang] || 'русском';

  return `Ты читаешь профиль Instagram и составляешь служебную заметку. Сообщение лицу НЕ пишешь — это сделает другой человек по твоей заметке.

ТВОЯ ЗАДАЧА: вытащить факты, которые дают повод написать этому человеку лично.
Повод — конкретика, которую он может узнать и о которой не думал как о рекламе.

ВЕРНИ ТОЛЬКО валидный JSON без markdown:
{"results":[{"username":"...","summary":"...","hooks":["...","...","..."]}]}

summary:
- Начинается со слов «В профиле», дальше без другого начала.
- От ${Math.round(maxWords * 0.6)} до ${maxWords} слов. Меньше — пусто, больше — перепиши.
- Пиши на ${langName}, термины из профиля оставляй как есть.
- Один абзац. Без списков, без заголовков, без нумерации.
- Порядок приоритета: чем зарабатывает → чему учит или о чём говорит → что делает
  регулярно → цифры, которые видны (аудитория, формат) → где принимает заявки.
- Если видно, чем он занят офлайн или что он сам продаёт — это самое ценное,
  выноси в начало.
- Без оценок («успешный», «крутой», «вдохновляет»), без предположений о доходах,
  возрасте, семье и характере. Не выдумывай то, чего нет в био и постах.

hooks — ровно ${HOOK_COUNT}, это главное:
- Каждый — обрывок из ${HOOK_MIN_WORDS}–${HOOK_MAX_WORDS} слов.
- Это не факты о человеке, а куски, с которых можно начать фразу в сообщении.
  Они должны читаться как начало живого высказывания, а не как тезис.
- Хорошо: «разбирает чужие ошибки в забегах», «ведёт офлайн-группы набором веса».
- Плохо: «является экспертом в области бега», «имеет большую аудиторию» —
  так пишут про всех подряд, и личное сообщение сразу становится шаблоном.
- Три разные детали, не перефразировки одной. Хотя бы один должен быть таким,
  который человек сам о себе не писал.

Верни ровно по одному объекту на каждый профиль, username как во входных данных.`;
}

function profileForPrompt(row, maxPosts) {
  const parts = [`username: ${row.username}`];
  if (row.full_name) parts.push(`имя: ${row.full_name}`);
  if (row.bio) parts.push(`био: ${String(row.bio).replace(/\s+/g, ' ').slice(0, 400)}`);
  if (Number.isFinite(Number(row.follower_count))) parts.push(`подписчиков: ${row.follower_count}`);
  if (Number.isFinite(Number(row.post_count))) parts.push(`постов: ${row.post_count}`);
  if (row.external_url) parts.push(`ссылка: ${row.external_url}`);
  if (row.is_private) parts.push('закрытый профиль, посты не видны');

  const posts = Array.isArray(row.posts) ? row.posts.filter(Boolean).slice(0, maxPosts) : [];
  if (posts.length) {
    parts.push('подписи постов (свежие сверху):');
    posts.forEach((p, i) => parts.push(`  ${i + 1}. ${String(p).replace(/\s+/g, ' ').slice(0, 220)}`));
  }
  return parts.join('\n');
}

// ---------------------------------------------------------------------------
// Generation
// ---------------------------------------------------------------------------

// Returns Map<username, {summary, hooks}>. Callers must tolerate a missing
// entry — a model that skips a profile leaves it for a retry rather than
// silently recording an empty note.
export async function enrichProfiles(db, rows, options = {}) {
  const batch = rows.slice(0, options.batchSize || ENRICH_BATCH);
  if (batch.length === 0) return new Map();

  const agent = normalizeAgentContext(options.agentContext);
  const policy = agent.policy;
  const maxWords = policy.summaryMaxWords;
  // The note is an internal document. By default it is written in Russian and
  // the DM is written in the recipient's language — mixing the two inside one
  // paragraph makes the model paraphrase Russian terms into the message.
  const summaryLang = policy.summaryLanguage === 'lead'
    ? (options.lang || batch[0].lang || 'ru')
    : 'ru';

  const systemPrompt = buildSystemPrompt({ summaryLang, maxWords });
  const userPrompt = `Профили:\n\n${
    batch.map((r, i) => `--- Профиль ${i + 1} ---\n${profileForPrompt(r, options.maxPosts || 8)}`).join('\n\n')
  }\n\nСоставь заметку и три крючка для каждого.`;

  const reply = await callOpenRouter(db, systemPrompt, userPrompt, 220 * batch.length, options.callOptions);
  const parsed = parseJsonReply(reply);
  const list = Array.isArray(parsed?.results) ? parsed.results : [];

  const out = new Map();
  for (const item of list) {
    const username = String(item?.username || '').trim().toLowerCase().replace(/^@/, '');
    if (!username) continue;

    let summary = clampWords(item.summary, maxWords);
    // The required opening is what makes the note readable as a note when a
    // human reviews it in the Contacts table, and it is stated in the contract
    // rather than trimmed off by the word clamp.
    if (summary && !/^в\s+профиле/i.test(summary)) summary = `В профиле ${summary}`;
    // Clamped again after the prefix so "В профиле" is paid for out of the
    // budget rather than added on top of it.
    summary = clampWords(summary, maxWords);

    const hooks = normalizeHooks(item.hooks);
    out.set(username, {
      summary,
      hooks,
      meta: {
        version: ENRICH_VERSION,
        model: options.model || null,
        summary_words: wordCount(summary),
        hook_words: hooks.map(wordCount),
        created_at: new Date().toISOString()
      }
    });
  }
  return out;
}

export { wordCount };
