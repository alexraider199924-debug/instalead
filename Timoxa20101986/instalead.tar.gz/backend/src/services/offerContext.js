// ---------------------------------------------------------------------------
// AI Agent field contract.
//
// One definition of every field the AI Agent tab owns, used by three callers
// that previously disagreed with each other:
//
//   * routes/ai-agents.js      — validates what a PUT may write, so an unknown
//                                key can never reach the table.
//   * routes/ai-agents.js GET  — hands the manifest to the UI, so the wizard
//                                renders from the same list instead of a copy
//                                that silently drifted. `voice_tone` was read by
//                                the prompt builder and had no input in the UI
//                                for months; that class of bug cannot survive a
//                                single manifest.
//   * services/personalizationEngine.js — turns stored rows into the prompt
//                                blocks, so a field that is collected is always
//                                a field that reaches the model.
//
// Stored rows stay flat ({field, value}) because the table is a key/value store.
// Everything structured (the offer, the voice, the personalization policy) is
// derived here, once, on read.
// ---------------------------------------------------------------------------

// type: 'textarea' | 'text' | 'select' | 'number'
// required: surfaced by /status so the UI can show what is still missing.
export const AGENT_SECTIONS = [
  {
    id: 'business',
    title: 'Бизнес и оффер',
    subtitle: 'Что вы предлагаете и кому. Эти поля объясняют модели, кому вообще подходит ваше предложение.',
    fields: [
      {
        key: 'product_name',
        label: 'Что вы продаёте / предлагаете',
        type: 'textarea',
        maxLength: 500,
        required: true,
        placeholder: 'Например: Курс по таргетированной рекламе для малого бизнеса',
        hint: 'Короткое название продукта. То, что вы произносите вслух клиенту в первые 5 секунд.'
      },
      {
        key: 'target_audience',
        label: 'Кто ваша целевая аудитория',
        type: 'textarea',
        maxLength: 500,
        required: true,
        placeholder: 'Например: Владельцы малого бизнеса, фрилансеры',
        hint: 'Модель сравнивает лида с этой группой. Если лид явно не из неё — сообщение всё равно должно звучать уместно.'
      },
      {
        key: 'problem_solved',
        label: 'Какую проблему вы решаете',
        type: 'textarea',
        maxLength: 500,
        required: true,
        placeholder: 'Например: Клиенты не знают, как настроить рекламу и сливают бюджет',
        hint: 'Формулируйте как боль клиента, а не как функцию продукта.'
      },
      {
        key: 'result_created',
        label: 'Какой результат получает клиент',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Стабильный поток клиентов из Instagram за 2 недели',
        hint: 'Обещание, которое встраивается в сообщение. Без конкретики оффер сливается с любым другим.'
      },
      {
        key: 'unique_value',
        label: 'Уникальное преимущество',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Личная обратная связь от практикующего таргетолога',
        hint: 'Причина выбрать вас, а не пять похожих исполнителей.'
      }
    ]
  },
  {
    id: 'offer',
    title: 'Оффер и призыв',
    subtitle: 'Структура предложения. Эти поля модель встраивает в сообщение — вместе с персонализацией, а не вместо неё.',
    fields: [
      {
        key: 'business_offer',
        label: 'Оффер одним предложением',
        type: 'textarea',
        maxLength: 500,
        required: true,
        placeholder: 'Например: Разбираю профиль и рекламу за 40 минут и даю план на 2 недели',
        hint: 'Главное. Что человек получит, если согласится. Пишите так, как сказали бы голосом.'
      },
      {
        key: 'offer_hook',
        label: 'Почему это важно сейчас',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Сейчас алгоритм режет охваты, и старые связки перестают приносить заявки',
        hint: 'Триггер актуальности. Даёт лиду причину ответить сегодня, а не «когда-нибудь».'
      },
      {
        key: 'offer_delivery',
        label: 'Как отдаёте',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Созвон в Zoom, 40 минут, разбор в записи',
        hint: 'Формат, длительность, где происходит. Отвечает на «а как это будет выглядеть».'
      },
      {
        key: 'offer_price',
        label: 'Цена',
        type: 'text',
        maxLength: 200,
        placeholder: 'Например: 15 000 ₽ / бесплатно / от 10 000 ₽',
        hint: 'Если цена в сообщении не нужна — оставьте пустым, и модель её не упомянет.'
      },
      {
        key: 'offer_cta',
        label: 'Призыв к действию',
        type: 'textarea',
        maxLength: 500,
        required: true,
        placeholder: 'Например: Скиньте профиль в директ — разберу бесплатно',
        hint: 'Один простой вопрос или предложение, на которое легко ответить «да». Главная причина ответить вообще.'
      }
    ]
  },
  {
    id: 'voice',
    title: 'Голос и тон',
    subtitle: 'Как именно вы пишете. Это то, что отличает сообщение от генератора.',
    fields: [
      {
        key: 'sender_name',
        label: 'Ваше имя (для подписи)',
        type: 'text',
        maxLength: 200,
        placeholder: 'Например: Алексей'
      },
      {
        key: 'tone',
        label: 'Базовый тон',
        type: 'select',
        options: [
          { value: 'friendly', label: 'Дружелюбный', desc: 'Тёплый, но без панибратства' },
          { value: 'neutral', label: 'Нейтральный', desc: 'Спокойный и универсальный' },
          { value: 'professional', label: 'Профессиональный', desc: 'Деловой, собранный' },
          { value: 'direct', label: 'Прямой', desc: 'Коротко, по делу, без подводных камней' }
        ]
      },
      {
        key: 'voice_tone',
        label: 'Голос своими словами',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Говорю без понтов, короткими фразами, без восклицательных знаков. Не «эксперт по…», а «я делаю это руками»',
        hint: 'Опишите свою манеру так, как объяснили бы её другу. Модель перенимает тон точнее, чем из прилагательного.'
      },
      {
        key: 'language',
        label: 'Язык сообщений',
        type: 'select',
        options: [
          { value: 'auto', label: 'Язык профиля лида (авто)' },
          { value: 'ru', label: 'Русский' },
          { value: 'en', label: 'English' },
          { value: 'es', label: 'Español' },
          { value: 'de', label: 'Deutsch' },
          { value: 'fr', label: 'Français' },
          { value: 'pt', label: 'Português' }
        ]
      },
      {
        key: 'sample_message',
        label: 'Пример сообщения в вашем стиле',
        type: 'textarea',
        maxLength: 500,
        placeholder: 'Например: Смотрю ваши кейсы по настройке рекламы. Как раз ищу систему, которая не сливает бюджет — есть пара мыслей, скинуть?',
        hint: 'Самый сильный сигнал стиля. Одно реальное сообщение, которое вы бы сами отправили.'
      }
    ]
  },
  {
    id: 'personalization',
    title: 'Персонализация',
    subtitle: 'Как собирается сообщение. Конспект профиля готовится здесь же, в обогащении контактов.',
    fields: [
      {
        key: 'personalization_opening',
        label: 'С чего начинать сообщение',
        type: 'select',
        options: [
          { value: 'profile_first', label: 'С детали о человеке', desc: 'Первая фраза — про него, оффер дальше' },
          { value: 'offer_first', label: 'С оффера', desc: 'Первая фраза — про вас, деталь дальше' }
        ]
      },
      {
        key: 'personalization_greeting',
        label: 'Обращение по имени',
        type: 'select',
        options: [
          { value: 'auto', label: 'Решает модель', desc: 'Имя, только если оно уместно' },
          { value: 'name', label: 'Всегда по имени', desc: '«Алексей, коротко…»' },
          { value: 'no_greeting', label: 'Без обращения', desc: 'Никаких «Привет, Иван»' }
        ]
      },
      {
        key: 'personalization_length',
        label: 'Длина сообщения, символов',
        type: 'number',
        min: 140,
        max: 800,
        step: 10,
        default: 420,
        hint: 'Instagram показывает ~400 символов до «ещё». Ниже 300 обрезает место под деталь о человеке, выше 500 листают.'
      },
      {
        key: 'summary_max_words',
        label: 'Длина конспекта профиля, слов',
        type: 'number',
        min: 30,
        max: 200,
        step: 10,
        default: 90,
        hint: 'Конспект — это то, что модель знает о человеке при рассылке. Короче = меньше повода для личного сообщения.'
      },
      {
        key: 'summary_language',
        label: 'Язык конспекта',
        type: 'select',
        options: [
          { value: 'ru', label: 'Русский (внутренний)', desc: 'Конспект на русском, сообщение на языке лида' },
          { value: 'lead', label: 'Как у лида', desc: 'Конспект на языке профиля' }
        ]
      }
    ]
  },
  {
    id: 'guardrails',
    title: 'Ограничения и ссылки',
    subtitle: 'Чего нельзя говорить и что можно отправить.',
    fields: [
      {
        key: 'boundaries',
        label: 'Запреты и ограничения',
        type: 'textarea',
        maxLength: 1000,
        placeholder: 'Не обещать конкретные результаты по доходу\nНе упоминать конкурентов\nНе давать скидки без согласования',
        hint: 'Каждое ограничение с новой строки. Проверяется после генерации, а не только в промпте.'
      },
      { key: 'link_website', label: 'Вебсайт', type: 'text', maxLength: 300, placeholder: 'https://example.com' },
      { key: 'link_instagram', label: 'Instagram', type: 'text', maxLength: 300, placeholder: 'https://instagram.com/yourpage' },
      { key: 'link_telegram', label: 'Telegram', type: 'text', maxLength: 300, placeholder: 'https://t.me/yourchannel' },
      { key: 'link_other', label: 'Другие ссылки', type: 'textarea', maxLength: 1000, placeholder: 'По одной на строку' }
    ]
  }
];

export const AGENT_FIELDS = AGENT_SECTIONS.flatMap(s => s.fields);
export const AGENT_FIELD_KEYS = AGENT_FIELDS.map(f => f.key);

const FIELD_BY_KEY = new Map(AGENT_FIELDS.map(f => [f.key, f]));

// Fields that predate the manifest. They are still written on a round trip so a
// GET → PUT from an older open tab cannot wipe data this version does not render.
export const LEGACY_AGENT_FIELDS = [
  'conversation_goal', 'qualification', 'questions_pricing', 'followups', 'links'
];

export const WRITABLE_AGENT_FIELDS = new Set([...AGENT_FIELD_KEYS, ...LEGACY_AGENT_FIELDS]);

export const REQUIRED_AGENT_FIELDS = AGENT_FIELDS.filter(f => f.required).map(f => f.key);

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

function clampInt(value, field) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return field.default ?? null;
  return Math.min(field.max ?? Infinity, Math.max(field.min ?? -Infinity, n));
}

// Coerces one incoming value to what its field can actually hold. Returns
// undefined for "do not write this key" so a partial PUT stays partial.
export function sanitizeAgentValue(key, rawValue) {
  const field = FIELD_BY_KEY.get(key);
  if (!field) {
    // Legacy free-text field: keep whatever the caller sent, bounded.
    return String(rawValue ?? '').slice(0, 2000);
  }

  if (rawValue === null || rawValue === undefined) return field.type === 'number' ? String(field.default ?? '') : '';

  if (field.type === 'number') {
    return String(clampInt(rawValue, field));
  }

  if (field.type === 'select') {
    const value = String(rawValue).trim();
    const allowed = field.options.map(o => o.value);
    // A previously saved value must survive a rule change, so unknown options
    // are stored as-is; only obviously wrong types fall back to the default.
    return allowed.includes(value) ? value : (field.options[0]?.value ?? '');
  }

  const text = String(rawValue).replace(/\r\n/g, '\n');
  return field.maxLength ? text.slice(0, field.maxLength) : text;
}

// ---------------------------------------------------------------------------
// Read + normalize
// ---------------------------------------------------------------------------

export function readAgentContextMap(db) {
  const rows = db.prepare('SELECT field, value FROM ai_business_context').all();
  const map = {};
  for (const row of rows) map[row.field] = String(row.value ?? '');
  return map;
}

const TONE_NAMES = {
  friendly: 'дружелюбный, тёплый, без панибратства',
  neutral: 'нейтральный, спокойный, универсальный',
  professional: 'профессиональный, деловой, собранный',
  direct: 'прямой, короткий, без заусложнений'
};

function line(label, value, max) {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  if (!text) return '';
  const body = max ? clip(text, max) : text;
  return `${label}: ${body}`;
}

function clip(text, max) {
  return text.length > max ? text.slice(0, max - 1) + '…' : text;
}

// agentContext arrives either as {field, value} rows (route layer) or as an
// already-flattened object (tests, callers that already hold the map).
export function toContextMap(agentContext) {
  if (!agentContext) return {};
  if (Array.isArray(agentContext)) {
    const map = {};
    for (const row of agentContext) {
      const value = String(row?.value ?? '').trim();
      if (value) map[row.field] = value;
    }
    return map;
  }
  const map = {};
  for (const [key, value] of Object.entries(agentContext)) {
    const text = String(value ?? '').trim();
    if (text) map[key] = text;
  }
  return map;
}

// Required-but-empty fields. Shared by the status endpoint and the send path so
// "the agent is configured" means one thing everywhere.
export function missingRequiredFields(agentContext) {
  const map = toContextMap(agentContext);
  return REQUIRED_AGENT_FIELDS.filter(key => !String(map[key] || '').trim());
}

// The single normalization used by every AI call that needs the agent. Returns
// pre-rendered prompt blocks plus the parsed policy values, so a caller never
// re-implements "what does opening=profile_first mean".
export function normalizeAgentContext(agentContext) {
  const map = toContextMap(agentContext);

  const opening = map.personalization_opening === 'offer_first' ? 'offer_first' : 'profile_first';
  const greeting = ['name', 'no_greeting'].includes(map.personalization_greeting)
    ? map.personalization_greeting
    : 'auto';
  const length = clampInt(map.personalization_length || 420, { min: 140, max: 800 });
  const summaryMaxWords = clampInt(map.summary_max_words || 90, { min: 30, max: 200 });
  const summaryLanguage = map.summary_language === 'lead' ? 'lead' : 'ru';
  const language = map.language || 'auto';
  const tone = TONE_NAMES[map.tone] ? map.tone : 'neutral';

  const offer = [
    line('ПРОДУКТ', map.product_name, 300),
    line('СУТЬ ОФФЕРА (что человек получит, если согласится)', map.business_offer || map.product_name, 400),
    line('ПОЧЕМУ АКТУАЛЬНО СЕЙЧАС', map.offer_hook, 300),
    line('ФОРМАТ И СПОСОБ', map.offer_delivery, 250),
    line('ЦЕНА', map.offer_price, 120),
    line('ЦЕЛЕВАЯ АУДИТОРИЯ', map.target_audience, 250),
    line('БОЛЬ КЛИЕНТА', map.problem_solved, 300),
    line('РЕЗУЛЬТАТ', map.result_created, 200),
    line('ЧЕМ ОТЛИЧАЕСЬ', map.unique_value, 250),
    line('ЧТО ПРОСИМ В ОТВЕТ (должен прозвучать в каждом сообщении)', map.offer_cta, 250)
  ].filter(Boolean).join('\n');

  const style = [
    line('ТОН', [TONE_NAMES[tone], map.voice_tone].filter(Boolean).join('. '), 300),
    line('ИМЯ ОТПРАВИТЕЛЯ', map.sender_name, 100),
    map.sample_message ? `ПРИМЕР ТОНА ОТПРАВИТЕЛЯ (ориентируйся на манеру, не на слова):\n${clip(map.sample_message, 500)}` : ''
  ].filter(Boolean).join('\n');

  const guardrails = [map.boundaries, map.qualification ? `Квалификация: ${map.qualification}` : '']
    .filter(Boolean).join('\n');

  const links = [
    map.link_website, map.link_instagram, map.link_telegram, map.link_other
  ].map(v => String(v || '').trim()).filter(Boolean);

  return {
    map,
    offer,
    offerText: offer,
    style,
    guardrails,
    links,
    sample: map.sample_message || '',
    boundaries: map.boundaries || '',
    // Parsed policy — the prompt builder and the quality gate both read these
    // instead of re-deriving intent from strings.
    policy: {
      opening,
      greeting,
      length,
      summaryMaxWords,
      summaryLanguage,
      language,
      tone,
      hasOffer: Boolean((map.business_offer || map.product_name || '').trim()),
      hasStyle: Boolean((map.voice_tone || map.sample_message || '').trim())
    }
  };
}

// Rendered instruction lines for the personalization policy. Kept next to the
// values that produce them so a new policy option cannot be added without
// stating what it means to the model.
export function policyInstructions(policy) {
  const parts = [];

  if (policy.opening === 'offer_first') {
    parts.push('НАЧНИ С ОФФЕРА: первая фраза — про предложение. Деталь из профиля встрой во вторую-третью.');
  } else {
    parts.push('НАЧНИ С ЧЕЛОВЕКА: первая фраза — про него, про то, что видно в его профиле. Оффер встрой следом, без «кстати, у нас есть…».');
  }

  if (policy.greeting === 'no_greeting') {
    parts.push('НЕ обращайся по имени и не начинай с приветствия.');
  } else if (policy.greeting === 'name') {
    parts.push('ОБРАЩАЙСЯ ПО ИМЕНИ в начале сообщения. Если имени нет — не выдумывай его, пиши без обращения.');
  } else {
    parts.push('Имя используй только если обращение звучит естественно. Фальшивое «Привет, @user» хуже, чем отсутствие имени.');
  }

  parts.push(`ДЛИНА: до ${policy.length} символов.`);
  return parts;
}
